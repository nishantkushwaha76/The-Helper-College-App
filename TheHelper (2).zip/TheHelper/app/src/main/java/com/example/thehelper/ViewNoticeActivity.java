package com.example.thehelper;

import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.firebase.ui.database.FirebaseListAdapter;
import com.firebase.ui.database.FirebaseListOptions;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

public class ViewNoticeActivity extends AppCompatActivity {

    private ListView lvNotices;
    private FirebaseListAdapter<NoticeModel> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_notice);

        lvNotices = findViewById(R.id.lvNotices);

        // 1. Fetch Data from "Notices" node in Firebase
        Query query = FirebaseDatabase.getInstance().getReference().child("Notices");

        // 2. Configure the Adapter options
        FirebaseListOptions<NoticeModel> options = new FirebaseListOptions.Builder<NoticeModel>()
                .setLayout(R.layout.item_notice) // This connects to your single item layout
                .setQuery(query, NoticeModel.class)
                .build();

        // 3. Initialize the Adapter
        adapter = new FirebaseListAdapter<NoticeModel>(options) {
            @Override
            protected void populateView(View v, NoticeModel model, int position) {
                // Bind data from model to the XML views in item_notice.xml
                TextView title = v.findViewById(R.id.tvNoticeTitleItem);
                TextView date = v.findViewById(R.id.tvNoticeDateItem);
                TextView msg = v.findViewById(R.id.tvNoticeMsgItem);

                title.setText(model.getTitle());
                date.setText(model.getDate());
                msg.setText(model.getMessage());
            }
        };

        // 4. Set Adapter to ListView
        lvNotices.setAdapter(adapter);
    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening(); // Start loading data
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening(); // Stop loading data to save battery
    }
}