package com.example.thehelper;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class SubjectAttendanceAdapter extends RecyclerView.Adapter<SubjectAttendanceAdapter.ViewHolder> {

    private List<SubjectAttendanceModel> subjectList;

    public SubjectAttendanceAdapter(List<SubjectAttendanceModel> subjectList) {
        this.subjectList = subjectList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Points to item_subject_attendance.xml (The Student Row Layout)
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_subject_attendance, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        SubjectAttendanceModel model = subjectList.get(position);

        // Bind Data
        holder.tvSubject.setText(model.getSubjectName());
        holder.tvPercent.setText(model.getPercentage());

        // This line will work now because we updated the Model in Step 1
        holder.tvAttended.setText("Attended: " + model.getPresentCount() + " / " + model.getTotalCount());

        try {
            // Convert "85%" to integer 85 for the progress bar
            String p = model.getPercentage().replace("%", "");
            holder.progressBar.setProgress((int) Float.parseFloat(p));
        } catch (Exception e) {
            holder.progressBar.setProgress(0);
        }
    }

    @Override
    public int getItemCount() {
        return subjectList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvSubject, tvPercent, tvAttended;
        ProgressBar progressBar;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // These IDs must match your item_subject_attendance.xml
            tvSubject = itemView.findViewById(R.id.tvSubjectName);
            tvPercent = itemView.findViewById(R.id.tvPercentage);
            tvAttended = itemView.findViewById(R.id.tvAttendedClasses);
            progressBar = itemView.findViewById(R.id.pbAttendance);
        }
    }
}