package com.example.thehelper;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.text.format.DateFormat;
import android.util.Base64;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.auth.FirebaseAuth;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.ViewHolder> {

    private Context context;
    private List<ChatModel> chatList;
    private String currentUid;
    private OnItemLongClickListener longClickListener;

    public interface OnItemLongClickListener {
        void onItemLongClick(int position);
    }

    public void setOnItemLongClickListener(OnItemLongClickListener listener) {
        this.longClickListener = listener;
    }

    public ChatAdapter(Context context, List<ChatModel> chatList) {
        this.context = context;
        this.chatList = chatList;
        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            this.currentUid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_chat, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ChatModel chat = chatList.get(position);

        holder.tvSender.setText(chat.getSenderName() + " (" + chat.getSenderRole() + ")");

        // 1. Message Type Logic (Text vs Image)
        if ("image".equals(chat.getType())) {
            holder.tvMessage.setVisibility(View.GONE);
            holder.ivChatImage.setVisibility(View.VISIBLE);
            try {
                byte[] decodedString = Base64.decode(chat.getImageUrl(), Base64.DEFAULT);
                Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                holder.ivChatImage.setImageBitmap(decodedByte);
            } catch (Exception e) {
                holder.ivChatImage.setVisibility(View.GONE);
            }
        } else {
            holder.tvMessage.setVisibility(View.VISIBLE);
            holder.ivChatImage.setVisibility(View.GONE);
            holder.tvMessage.setText(chat.getMessage());
        }

        // 2. Timestamp Formatting
        Calendar cal = Calendar.getInstance(Locale.ENGLISH);
        cal.setTimeInMillis(chat.getTimestamp());
        holder.tvTime.setText(DateFormat.format("hh:mm a", cal).toString());

        // 3. FIXED ALIGNMENT LOGIC (Prevents ClassCastException)
        // Instead of casting to LinearLayout.LayoutParams, we modify the Gravity of the item view's root
        if (chat.getSenderUid() != null && chat.getSenderUid().equals(currentUid)) {
            // SENT BY ME: Align Right
            holder.rootLayout.setGravity(Gravity.END);
            holder.tvMessage.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#D1C4E9")));
            holder.tvSender.setTextColor(Color.parseColor("#673AB7"));
            holder.tvSender.setGravity(Gravity.END);
            holder.tvTime.setGravity(Gravity.END);
        } else {
            // RECEIVED: Align Left
            holder.rootLayout.setGravity(Gravity.START);
            holder.tvMessage.setBackgroundTintList(ColorStateList.valueOf(Color.WHITE));
            holder.tvSender.setTextColor(Color.parseColor("#3F51B5"));
            holder.tvSender.setGravity(Gravity.START);
            holder.tvTime.setGravity(Gravity.START);
        }

        // 4. Long Click Logic for Deleting
        View.OnLongClickListener longClick = v -> {
            if (longClickListener != null) longClickListener.onItemLongClick(holder.getAdapterPosition());
            return true;
        };
        holder.tvMessage.setOnLongClickListener(longClick);
        holder.ivChatImage.setOnLongClickListener(longClick);
    }

    @Override
    public int getItemCount() { return chatList.size(); }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvSender, tvMessage, tvTime;
        ImageView ivChatImage;
        LinearLayout rootLayout; // This maps to the top-level container in item_chat.xml

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvSender = itemView.findViewById(R.id.tvSenderName);
            tvMessage = itemView.findViewById(R.id.tvChatMessage);
            tvTime = itemView.findViewById(R.id.tvTimestamp);
            ivChatImage = itemView.findViewById(R.id.ivChatImage);
            // We cast the root view of the item to LinearLayout to set gravity
            rootLayout = (LinearLayout) itemView;
        }
    }
}