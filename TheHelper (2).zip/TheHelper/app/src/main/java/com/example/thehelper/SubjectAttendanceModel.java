package com.example.thehelper;

public class SubjectAttendanceModel {
    private String subjectName;
    private String presentCount;
    private String totalCount;

    // Constructor
    public SubjectAttendanceModel(String subjectName, String presentCount, String totalCount) {
        this.subjectName = subjectName;
        this.presentCount = presentCount;
        this.totalCount = totalCount;
    }

    // Getters - These were missing, causing your Adapter to fail!
    public String getSubjectName() {
        return subjectName;
    }

    public String getPresentCount() {
        return presentCount;
    }

    public String getTotalCount() {
        return totalCount;
    }

    // Helper to calculate "85%"
    public String getPercentage() {
        try {
            float p = Float.parseFloat(presentCount);
            float t = Float.parseFloat(totalCount);
            if (t == 0) return "0%";
            float percent = (p / t) * 100;
            return String.format("%.0f%%", percent);
        } catch (Exception e) {
            return "0%";
        }
    }
}