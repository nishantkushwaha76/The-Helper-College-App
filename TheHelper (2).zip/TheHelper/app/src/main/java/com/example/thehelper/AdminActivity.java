package com.example.thehelper;

import android.app.DatePickerDialog;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

public class AdminActivity extends AppCompatActivity {

    private LinearLayout layoutSelection;
    private LinearLayout layoutStudentForm, layoutTeacherForm, layoutResultForm;
    private LinearLayout layoutScheduleForm, layoutLiveClassForm, layoutExamAlertForm;
    private LinearLayout layoutManageTeacherForm;

    private CardView cardStudent, cardTeacher, cardResult;
    private CardView cardSchedule, cardLiveClass, cardExamAlert;
    private CardView cardManageTeachers, cardNoticeBoard;

    // 1. Student Authorization
    private EditText etSName, etPRN, etSBranch, etSSem, etSDiv;
    private Button btnSaveStudent, btnBackS;

    // 2. Teacher Assignment
    private EditText etTID, etTName, etTBranch, etTSem, etTDiv;
    private Spinner spTSubject;
    private Spinner spTeacherPosition;
    private Button btnSaveTeacher, btnBackT, btnTLoadSubjects;

    // 3. Result Upload
    private EditText etR_PRN;
    private TextView tvMarksheetStatus;
    private Button btnSelectMarksheet, btnUploadMarksheet, btnBackR;
    private Uri marksheetUri;

    // 4. PDF Schedule
    private Spinner spAdminCategory;
    private EditText etAdminBranch, etAdminSem, etScheduleTitle;
    private TextView tvAdminFileStatus;
    private Uri pdfUri;
    private Button btnSelectFile, btnUploadSchedule, btnBackSchedule;

    // 5. Live Class (TIMETABLE)
    private Spinner spTimeBranch, spTimeSem, spTimeDiv, spTimeDay, spTimeSlot, spTimeSubject;
    private Button btnSaveLiveClass, btnBackLiveClass, btnTimeLoadSubjects;

    // 6. Exam Alert
    private EditText etExamBranch, etExamSem, etExamDate, etExamTime;
    private Spinner spExamSubject, spExamDuration;
    private Button btnSaveExamAlert, btnBackExamAlert, btnExamLoadSubjects;

    // 7. Manage Teachers
    private Spinner spAllTeachers, spTeacherDay;
    private Spinner spTeacherTime;
    private EditText etTeacherDetails;
    private Button btnDeleteTeacher, btnUpdateTeacherSchedule, btnBackManageTeacher;
    private List<String> teacherNames = new ArrayList<>();
    private List<String> teacherUids = new ArrayList<>();

    private Button btnLogout;
    private DatabaseReference dbRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        dbRef = FirebaseDatabase.getInstance().getReference();

        // Layout Initializations
        layoutSelection = findViewById(R.id.layoutSelection);
        layoutStudentForm = findViewById(R.id.layoutStudentForm);
        layoutTeacherForm = findViewById(R.id.layoutTeacherForm);
        layoutResultForm = findViewById(R.id.layoutResultForm);
        layoutScheduleForm = findViewById(R.id.layoutScheduleForm);
        layoutLiveClassForm = findViewById(R.id.layoutLiveClassForm);
        layoutExamAlertForm = findViewById(R.id.layoutExamAlertForm);
        layoutManageTeacherForm = findViewById(R.id.layoutManageTeacherForm);

        // Card Initializations
        cardStudent = findViewById(R.id.cardSelectStudent);
        cardTeacher = findViewById(R.id.cardSelectTeacher);
        cardResult = findViewById(R.id.cardSelectResult);
        cardSchedule = findViewById(R.id.cardSelectSchedule);
        cardLiveClass = findViewById(R.id.cardLiveClass);
        cardExamAlert = findViewById(R.id.cardExamAlert);
        cardManageTeachers = findViewById(R.id.cardManageTeachers);
        cardNoticeBoard = findViewById(R.id.cardNoticeBoard);

        btnLogout = findViewById(R.id.btnLogoutAdmin);

        initStudentFields();
        initTeacherFields();
        initResultFields();
        initScheduleFields();
        initLiveClassFields();
        initExamAlertFields();
        initManageTeacherFields();

        // Navigation Listeners
        cardStudent.setOnClickListener(v -> showForm(layoutStudentForm));
        cardTeacher.setOnClickListener(v -> showForm(layoutTeacherForm));
        cardResult.setOnClickListener(v -> showForm(layoutResultForm));
        cardSchedule.setOnClickListener(v -> showForm(layoutScheduleForm));
        cardLiveClass.setOnClickListener(v -> showForm(layoutLiveClassForm));
        cardExamAlert.setOnClickListener(v -> showForm(layoutExamAlertForm));
        cardNoticeBoard.setOnClickListener(v -> showNoticeDialog());

        cardManageTeachers.setOnClickListener(v -> {
            loadTeacherList();
            showForm(layoutManageTeacherForm);
        });

        View.OnClickListener backListener = v -> showSelection();
        btnBackS.setOnClickListener(backListener);
        btnBackT.setOnClickListener(backListener);
        btnBackR.setOnClickListener(backListener);
        btnBackSchedule.setOnClickListener(backListener);
        btnBackLiveClass.setOnClickListener(backListener);
        btnBackExamAlert.setOnClickListener(backListener);
        btnBackManageTeacher.setOnClickListener(backListener);

        // Save Logic
        btnSaveTeacher.setOnClickListener(v -> saveTeacherAssignment());
        btnSaveStudent.setOnClickListener(v -> saveStudentAuthorization());
        btnSelectMarksheet.setOnClickListener(v -> selectImage(102));
        btnUploadMarksheet.setOnClickListener(v -> uploadOfficialMarksheet());
        btnSelectFile.setOnClickListener(v -> selectPDF());
        btnUploadSchedule.setOnClickListener(v -> uploadOfficialSchedule());
        btnSaveLiveClass.setOnClickListener(v -> saveLiveClassSlot());
        btnSaveExamAlert.setOnClickListener(v -> saveExamAlert());
        btnDeleteTeacher.setOnClickListener(v -> deleteSelectedTeacher());
        btnUpdateTeacherSchedule.setOnClickListener(v -> saveTeacherPersonalSchedule());

        btnLogout.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }

    private void showNoticeDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("📢 Post New Notice");
        final EditText input = new EditText(this);
        input.setHint("Type urgent notice here...");
        builder.setView(input);
        builder.setPositiveButton("Post", (dialog, which) -> {
            String notice = input.getText().toString().trim();
            if (!notice.isEmpty()) {
                String key = dbRef.child("Notices").push().getKey();
                HashMap<String, String> noticeMap = new HashMap<>();
                noticeMap.put("title", "Admin Notice");
                noticeMap.put("message", notice);
                noticeMap.put("date", "Urgent");

                if (key != null) {
                    dbRef.child("Notices").child(key).setValue(noticeMap)
                            .addOnSuccessListener(aVoid -> Toast.makeText(this, "Notice Posted!", Toast.LENGTH_SHORT).show());
                }
            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void showForm(LinearLayout form) {
        layoutSelection.setVisibility(View.GONE);
        layoutStudentForm.setVisibility(View.GONE);
        layoutTeacherForm.setVisibility(View.GONE);
        layoutResultForm.setVisibility(View.GONE);
        layoutScheduleForm.setVisibility(View.GONE);
        layoutLiveClassForm.setVisibility(View.GONE);
        layoutExamAlertForm.setVisibility(View.GONE);
        layoutManageTeacherForm.setVisibility(View.GONE);
        form.setVisibility(View.VISIBLE);
    }

    private void showSelection() {
        layoutSelection.setVisibility(View.VISIBLE);
        layoutStudentForm.setVisibility(View.GONE);
        layoutTeacherForm.setVisibility(View.GONE);
        layoutResultForm.setVisibility(View.GONE);
        layoutScheduleForm.setVisibility(View.GONE);
        layoutLiveClassForm.setVisibility(View.GONE);
        layoutExamAlertForm.setVisibility(View.GONE);
        layoutManageTeacherForm.setVisibility(View.GONE);
    }

    // --- Init Methods ---

    private void initStudentFields() {
        etSName = findViewById(R.id.etStudentName);
        etPRN = findViewById(R.id.etStudentPRN);
        etSBranch = findViewById(R.id.etBranch);
        etSSem = findViewById(R.id.etSem);
        etSDiv = findViewById(R.id.etStudentDiv);
        btnSaveStudent = findViewById(R.id.btnAddStudent);
        btnBackS = findViewById(R.id.btnBackStudent);
    }

    private void initTeacherFields() {
        etTID = findViewById(R.id.etTeacherID);
        etTName = findViewById(R.id.etTeaAcherName);
        etTBranch = findViewById(R.id.etTeacherBranch);
        etTSem = findViewById(R.id.etTeacherSem);
        etTDiv = findViewById(R.id.etTeacherDiv);
        spTSubject = findViewById(R.id.spTSubject);
        spTeacherPosition = findViewById(R.id.spTeacherPosition);
        btnTLoadSubjects = findViewById(R.id.btnTLoadSubjects);
        btnSaveTeacher = findViewById(R.id.btnAddTeacher);
        btnBackT = findViewById(R.id.btnBackTeacher);

        btnTLoadSubjects.setOnClickListener(v -> loadSubjectsForTeacher());
        String[] positions = {"Subject Teacher", "GFM (Class Teacher)", "HOD"};
        spTeacherPosition.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, positions));
    }

    private void initResultFields() {
        etR_PRN = findViewById(R.id.etResultPrn);
        tvMarksheetStatus = findViewById(R.id.tvAdminFileStatus);
        btnSelectMarksheet = findViewById(R.id.btnSelectAdminFile);
        btnUploadMarksheet = findViewById(R.id.btnUploadSchedule);
        btnBackR = findViewById(R.id.btnBackMarks);
        btnSelectMarksheet.setText("Select Marksheet Image");
        btnUploadMarksheet.setText("Upload Marksheet");
    }

    private void selectImage(int requestCode) {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, requestCode);
    }

    private void initScheduleFields() {
        spAdminCategory = findViewById(R.id.spAdminCategory);
        etAdminBranch = findViewById(R.id.etAdminBranch);
        etAdminSem = findViewById(R.id.etAdminSem);
        etScheduleTitle = findViewById(R.id.etScheduleTitle);
        tvAdminFileStatus = findViewById(R.id.tvAdminFileStatus);
        btnSelectFile = findViewById(R.id.btnSelectFile);
        btnUploadSchedule = findViewById(R.id.btnUploadSchedulePDF);
        btnBackSchedule = findViewById(R.id.btnBackSchedule);
        String[] categories = {"Exam Schedule", "Academic Calendar", "Class Timetable"};
        spAdminCategory.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, categories));
    }

    private void initLiveClassFields() {
        spTimeBranch = findViewById(R.id.spTimeBranch);
        spTimeSem = findViewById(R.id.spTimeSem);
        spTimeDiv = findViewById(R.id.spTimeDiv);
        spTimeDay = findViewById(R.id.spTimeDay);
        spTimeSlot = findViewById(R.id.spTimeSlot);
        spTimeSubject = findViewById(R.id.spTimeSubject);

        btnTimeLoadSubjects = findViewById(R.id.btnTimeLoadSubjects);
        btnSaveLiveClass = findViewById(R.id.btnSaveLiveClass);
        btnBackLiveClass = findViewById(R.id.btnBackLiveClass);

        String[] branches = {"CSE", "CE", "IT", "MECH", "CHEM", "CSBS", "ENTC"};
        spTimeBranch.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, branches));

        String[] sems = {"1", "2", "3", "4", "5", "6", "7", "8"};
        spTimeSem.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, sems));

        String[] divs = {"A", "B", "C"};
        spTimeDiv.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, divs));

        String[] days = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
        spTimeDay.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, days));

        String[] slots = {"09:00 AM - 10:00 AM", "10:00 AM - 11:00 AM", "11:15 AM - 12:15 PM", "12:15 PM - 01:15 PM", "02:00 PM - 03:00 PM", "03:00 PM - 04:00 PM", "04:15 PM - 05:15 PM"};
        spTimeSlot.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, slots));

        btnTimeLoadSubjects.setOnClickListener(v -> loadSubjectsForLiveClass());
        btnSaveLiveClass.setOnClickListener(v -> saveLiveClassSlot());
    }

    // --- 1. LIVE CLASS SUBJECT LOADER (Format: CSE_SEM 3) ---
    private void loadSubjectsForLiveClass() {
        String branch = spTimeBranch.getSelectedItem().toString(); // e.g. "CSE"
        String sem = spTimeSem.getSelectedItem().toString();       // e.g. "3"

        // This line matches your JSON exactly
        String key = branch + "_SEM " + sem;

        ProgressDialog pd = new ProgressDialog(this);
        pd.setMessage("Fetching Subjects...");
        pd.show();

        dbRef.child("Subjects").child(key).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                pd.dismiss();
                List<String> subjects = new ArrayList<>();
                if (snapshot.exists()) {
                    for (DataSnapshot s : snapshot.getChildren()) {
                        String subName = s.getValue(String.class);
                        if (subName != null) subjects.add(subName);
                    }
                    spTimeSubject.setAdapter(new ArrayAdapter<>(AdminActivity.this, android.R.layout.simple_spinner_dropdown_item, subjects));
                    Toast.makeText(AdminActivity.this, "Subjects Loaded!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(AdminActivity.this, "No subjects found for " + key, Toast.LENGTH_SHORT).show();
                    spTimeSubject.setAdapter(null);
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) { pd.dismiss(); }
        });
    }

    private void saveLiveClassSlot() {
        if (spTimeSubject.getSelectedItem() == null) return;

        String branch = spTimeBranch.getSelectedItem().toString();
        String sem = spTimeSem.getSelectedItem().toString();
        String div = spTimeDiv.getSelectedItem().toString();

        // SAVES AS: CSE_3_A (Clean Format for App)
        String pathKey = branch + "_" + sem + "_" + div;

        String day = spTimeDay.getSelectedItem().toString();
        String slot = spTimeSlot.getSelectedItem().toString();
        String subject = spTimeSubject.getSelectedItem().toString();

        dbRef.child("Timetable").child(pathKey).child(day).child(slot).setValue(subject)
                .addOnSuccessListener(v -> Toast.makeText(this, "Timetable Updated for " + div, Toast.LENGTH_SHORT).show())
                .addOnFailureListener(e -> Toast.makeText(this, "Failed", Toast.LENGTH_SHORT).show());
    }

    private void initExamAlertFields() {
        etExamBranch = findViewById(R.id.etExamBranch);
        etExamSem = findViewById(R.id.etExamSem);
        etExamDate = findViewById(R.id.etExamDate);
        etExamTime = findViewById(R.id.etExamTime);

        spExamSubject = findViewById(R.id.spExamSubject);
        spExamDuration = findViewById(R.id.spExamDuration);

        btnExamLoadSubjects = findViewById(R.id.btnExamLoadSubjects);
        btnSaveExamAlert = findViewById(R.id.btnSaveExamAlert);
        btnBackExamAlert = findViewById(R.id.btnBackExamAlert);

        etExamDate.setFocusable(false);
        etExamDate.setClickable(true);
        etExamDate.setOnClickListener(v -> showDatePicker());

        String[] durations = {"1 Hour", "1.5 Hours", "2 Hours", "2.5 Hours", "3 Hours"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, durations);
        spExamDuration.setAdapter(adapter);

        btnExamLoadSubjects.setOnClickListener(v -> loadSubjectsForExam());
    }

    private void showDatePicker() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, year1, month1, dayOfMonth) -> {
                    String selectedDate = String.format(Locale.getDefault(), "%04d-%02d-%02d", year1, month1 + 1, dayOfMonth);
                    etExamDate.setText(selectedDate);
                }, year, month, day);
        datePickerDialog.show();
    }

    // --- 2. EXAM SUBJECT LOADER (Format: CSE_SEM 3) ---
    private void loadSubjectsForExam() {
        String branch = etExamBranch.getText().toString().trim().toUpperCase();
        String rawSem = etExamSem.getText().toString().trim();
        // Remove "Sem" if user typed it, to get just "3"
        String sem = rawSem.toLowerCase().replace("sem", "").replace(" ", "");

        if (branch.isEmpty() || sem.isEmpty()) {
            Toast.makeText(this, "Enter Branch and Sem", Toast.LENGTH_SHORT).show();
            return;
        }

        // This matches your JSON
        String key = branch + "_SEM " + sem;

        dbRef.child("Subjects").child(key).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<String> subjects = new ArrayList<>();
                for (DataSnapshot s : snapshot.getChildren()) {
                    subjects.add(s.getValue(String.class));
                }
                if (!subjects.isEmpty()) {
                    spExamSubject.setAdapter(new ArrayAdapter<>(AdminActivity.this, android.R.layout.simple_spinner_dropdown_item, subjects));
                    Toast.makeText(AdminActivity.this, "Subjects Loaded", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(AdminActivity.this, "No subjects found in " + key, Toast.LENGTH_SHORT).show();
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void saveExamAlert() {
        String branch = etExamBranch.getText().toString().trim().toUpperCase();
        String rawSem = etExamSem.getText().toString().trim();
        String sem = rawSem.toLowerCase().replace("sem", "").replace(" ", "");

        String date = etExamDate.getText().toString().trim();
        String time = etExamTime.getText().toString().trim();

        if (branch.isEmpty() || sem.isEmpty() || date.isEmpty() || time.isEmpty() || spExamSubject.getSelectedItem() == null) {
            Toast.makeText(this, "Please fill all details", Toast.LENGTH_SHORT).show();
            return;
        }

        String subject = spExamSubject.getSelectedItem().toString();
        String duration = spExamDuration.getSelectedItem().toString();

        // SAVES AS: CSE_3 (Clean Format for App)
        String path = branch + "_" + sem;

        HashMap<String, String> examMap = new HashMap<>();
        examMap.put("subject", subject);
        examMap.put("time", time);
        examMap.put("duration", duration);

        dbRef.child("Exams").child(path).child(date).setValue(examMap)
                .addOnSuccessListener(v -> {
                    Toast.makeText(this, "Exam Scheduled!", Toast.LENGTH_SHORT).show();
                    showSelection();
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Failed to save exam", Toast.LENGTH_SHORT).show());
    }

    private void initManageTeacherFields() {
        spAllTeachers = findViewById(R.id.spAllTeachers);
        spTeacherDay = findViewById(R.id.spTeacherDay);
        spTeacherTime = findViewById(R.id.spTeacherTime);
        etTeacherDetails = findViewById(R.id.etTeacherDetails);
        btnDeleteTeacher = findViewById(R.id.btnDeleteTeacher);
        btnUpdateTeacherSchedule = findViewById(R.id.btnUpdateTeacherSchedule);
        btnBackManageTeacher = findViewById(R.id.btnBackManageTeacher);
        String[] days = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
        spTeacherDay.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, days));
        String[] timeSlots = {"09:00 AM - 10:00 AM", "10:00 AM - 11:00 AM", "11:15 AM - 12:15 PM", "12:15 PM - 01:15 PM", "02:00 PM - 03:00 PM", "03:00 PM - 04:00 PM", "04:15 PM - 05:15 PM"};
        spTeacherTime.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, timeSlots));
    }

    private void loadTeacherList() {
        dbRef.child("Users").orderByChild("role").equalTo("Teacher").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                teacherNames.clear(); teacherUids.clear();
                for (DataSnapshot s : snapshot.getChildren()) {
                    teacherNames.add(s.child("fullName").getValue(String.class));
                    teacherUids.add(s.getKey());
                }
                spAllTeachers.setAdapter(new ArrayAdapter<>(AdminActivity.this, android.R.layout.simple_spinner_dropdown_item, teacherNames));
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void deleteSelectedTeacher() {
        int pos = spAllTeachers.getSelectedItemPosition();
        if (pos >= 0) {
            dbRef.child("Users").child(teacherUids.get(pos)).removeValue();
            loadTeacherList();
        }
    }

    private void saveTeacherPersonalSchedule() {
        int pos = spAllTeachers.getSelectedItemPosition();
        if (pos >= 0) {
            String selectedTime = spTeacherTime.getSelectedItem().toString();
            dbRef.child("TeacherTimetable").child(teacherUids.get(pos)).child(spTeacherDay.getSelectedItem().toString())
                    .child(selectedTime).setValue(etTeacherDetails.getText().toString());
            Toast.makeText(this, "Schedule Updated!", Toast.LENGTH_SHORT).show();
        }
    }

    // --- 3. TEACHER SUBJECT LOADER (Format: CSE_SEM 3) ---
    private void loadSubjectsForTeacher() {
        String branch = etTBranch.getText().toString().trim().toUpperCase();
        String rawSem = etTSem.getText().toString().trim();
        // Remove "Sem" if user typed it
        String sem = rawSem.toLowerCase().replace("sem", "").replace(" ", "");

        if (branch.isEmpty() || sem.isEmpty()) return;

        // This matches your JSON
        String key = branch + "_SEM " + sem;

        dbRef.child("Subjects").child(key).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<String> subjects = new ArrayList<>();
                for (DataSnapshot s : snapshot.getChildren()) subjects.add(s.getValue(String.class));
                spTSubject.setAdapter(new ArrayAdapter<>(AdminActivity.this, android.R.layout.simple_spinner_dropdown_item, subjects));
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    // --- IMPORTANT: SAVE TEACHER WITH CLEAN DATA (Format: CSE, 3) ---
    private void saveTeacherAssignment() {
        String teacherId = etTID.getText().toString().trim();
        String branch = etTBranch.getText().toString().trim();
        String rawSem = etTSem.getText().toString().trim();

        // Clean the semester so Teacher App works (removes "Sem", gives "3")
        String sem = rawSem.toLowerCase().replace("sem", "").replace(" ", "");

        String name = etTName.getText().toString().trim();
        String div = etTDiv.getText().toString().trim();

        if(teacherId.isEmpty() || branch.isEmpty() || sem.isEmpty()){
            Toast.makeText(this, "Please fill required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        HashMap<String, Object> assignment = new HashMap<>();
        assignment.put("name", name);
        assignment.put("branch", branch);
        assignment.put("semester", sem); // Saves as "3"
        assignment.put("division", div.isEmpty() ? "A" : div);

        if (spTSubject.getSelectedItem() != null) {
            assignment.put("subject", spTSubject.getSelectedItem().toString());
        } else {
            assignment.put("subject", "General");
        }
        assignment.put("position", spTeacherPosition.getSelectedItem().toString());

        dbRef.child("Teachers").child(teacherId).setValue(assignment)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Teacher Assigned Successfully!", Toast.LENGTH_SHORT).show();
                    showSelection();
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Failed.", Toast.LENGTH_SHORT).show());
    }

    // --- IMPORTANT: SAVE STUDENT WITH CLEAN DATA (Format: CSE, 3) ---
    private void saveStudentAuthorization() {
        String prn = etPRN.getText().toString().trim();
        String branch = etSBranch.getText().toString().trim();
        String rawSem = etSSem.getText().toString().trim();

        // Clean the semester so Student App works
        String sem = rawSem.toLowerCase().replace("sem", "").replace(" ", "");

        if(prn.isEmpty() || branch.isEmpty() || sem.isEmpty()){
            Toast.makeText(this, "Enter PRN, Branch and Sem", Toast.LENGTH_SHORT).show();
            return;
        }

        HashMap<String, Object> studentData = new HashMap<>();
        studentData.put("name", etSName.getText().toString());
        studentData.put("branch", branch);
        studentData.put("semester", sem); // Saves as "3"
        studentData.put("division", etSDiv.getText().toString().trim());

        dbRef.child("Students").child(prn).setValue(studentData).addOnSuccessListener(aVoid -> showSelection());
    }

    private void selectPDF() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("application/pdf");
        startActivityForResult(intent, 101);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            if (requestCode == 101) {
                pdfUri = data.getData();
                tvAdminFileStatus.setText("PDF Selected");
            } else if (requestCode == 102) {
                marksheetUri = data.getData();
                tvMarksheetStatus.setText("Image Selected");
            }
        }
    }

    private void uploadOfficialSchedule() {
        if (pdfUri == null) return;
        ProgressDialog pd = new ProgressDialog(this);
        pd.setMessage("Uploading PDF...");
        pd.show();

        String b = etAdminBranch.getText().toString().trim();
        String s = etAdminSem.getText().toString().trim();
        String branchSemKey = b + "_" + s;
        String category = spAdminCategory.getSelectedItem().toString();

        StorageReference storageRef = FirebaseStorage.getInstance().getReference().child("Materials/" + branchSemKey + "/" + category + "/" + System.currentTimeMillis() + ".pdf");
        storageRef.putFile(pdfUri).addOnSuccessListener(taskSnapshot -> {
            storageRef.getDownloadUrl().addOnSuccessListener(uri -> {
                UploadModel upload = new UploadModel(etScheduleTitle.getText().toString(), uri.toString());
                dbRef.child("Materials").child(branchSemKey).child(category).push().setValue(upload).addOnSuccessListener(aVoid -> {
                    pd.dismiss();
                    Toast.makeText(this, "Uploaded Successfully", Toast.LENGTH_SHORT).show();
                    showSelection();
                });
            });
        }).addOnFailureListener(e -> pd.dismiss());
    }

    private void uploadOfficialMarksheet() {
        String prn = etR_PRN.getText().toString().trim();
        if (marksheetUri == null || prn.isEmpty()) {
            Toast.makeText(this, "Enter PRN & Select Image", Toast.LENGTH_SHORT).show();
            return;
        }
        ProgressDialog pd = new ProgressDialog(this);
        pd.setMessage("Uploading Marksheet...");
        pd.show();

        StorageReference storageRef = FirebaseStorage.getInstance().getReference().child("Marksheets/" + prn + ".jpg");
        storageRef.putFile(marksheetUri).addOnSuccessListener(taskSnapshot -> {
            storageRef.getDownloadUrl().addOnSuccessListener(uri -> {
                dbRef.child("Results").child(prn).child("officialMarksheet").setValue(uri.toString())
                        .addOnSuccessListener(aVoid -> {
                            pd.dismiss();
                            Toast.makeText(this, "Marksheet Saved!", Toast.LENGTH_SHORT).show();
                            showSelection();
                        });
            });
        }).addOnFailureListener(e -> {
            pd.dismiss();
            Toast.makeText(this, "Upload Failed", Toast.LENGTH_SHORT).show();
        });
    }
}