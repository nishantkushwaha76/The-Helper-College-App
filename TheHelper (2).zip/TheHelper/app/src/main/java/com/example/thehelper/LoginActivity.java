package com.example.thehelper;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LoginActivity extends AppCompatActivity {

    private EditText userIdField, passwordField;
    private Button loginButton;
    private TextView registerRedirect;
    private RadioGroup roleGroup;
    private RadioButton rbStudent, rbTeacher, rbAdmin;
    private FirebaseAuth mAuth;
    private DatabaseReference mDbRef;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mAuth = FirebaseAuth.getInstance();
        mDbRef = FirebaseDatabase.getInstance().getReference("Users");

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Logging in...");
        progressDialog.setCancelable(false);

        // Link UI
        userIdField = findViewById(R.id.userIdField);
        passwordField = findViewById(R.id.passwordField);
        loginButton = findViewById(R.id.loginButton);
        registerRedirect = findViewById(R.id.registerRedirect);
        roleGroup = findViewById(R.id.roleRadioGroup);
        rbStudent = findViewById(R.id.rbStudent);
        rbTeacher = findViewById(R.id.rbTeacher);
        rbAdmin = findViewById(R.id.rbAdmin);

        // 1. Set default InputType for Student (since it's checked by default in XML)
        userIdField.setHint("Enter PRN Number");
        userIdField.setInputType(InputType.TYPE_CLASS_NUMBER);

        // 2. Change Hint and InputType based on selection
        roleGroup.setOnCheckedChangeListener((group, checkedId) -> {
            userIdField.setText(""); // Clear field when switching roles
            if (checkedId == R.id.rbStudent) {
                userIdField.setHint("Enter PRN Number");
                userIdField.setInputType(InputType.TYPE_CLASS_NUMBER);
            } else if (checkedId == R.id.rbTeacher) {
                userIdField.setHint("Enter Teacher ID");
                userIdField.setInputType(InputType.TYPE_CLASS_TEXT);
            } else if (checkedId == R.id.rbAdmin) {
                userIdField.setHint("Enter Admin Email");
                userIdField.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
            }
        });

        // 3. Check if user is already logged in
        if (mAuth.getCurrentUser() != null) {
            progressDialog.show();
            verifyRoleAndRedirect(mAuth.getCurrentUser().getUid());
        }

        loginButton.setOnClickListener(v -> performLogin());

        registerRedirect.setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
        });
    }

    private void performLogin() {
        String inputID = userIdField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();

        if (TextUtils.isEmpty(inputID) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        String finalEmail = "";
        if (rbStudent.isChecked()) {
            finalEmail = inputID + "@helper.com";
        } else if (rbTeacher.isChecked()) {
            finalEmail = inputID + "@staff.com";
        } else if (rbAdmin.isChecked()) {
            finalEmail = inputID; // Admin types full email
        } else {
            Toast.makeText(this, "Please select a role", Toast.LENGTH_SHORT).show();
            return;
        }

        // Special Master Admin Bypass
        if(finalEmail.equalsIgnoreCase("admin@gmail.com") && password.equals("123456")) {
            startActivity(new Intent(LoginActivity.this, AdminActivity.class));
            finish();
            return;
        }

        progressDialog.show();

        mAuth.signInWithEmailAndPassword(finalEmail, password)
                .addOnSuccessListener(authResult -> {
                    verifyRoleAndRedirect(authResult.getUser().getUid());
                })
                .addOnFailureListener(e -> {
                    progressDialog.dismiss();
                    Toast.makeText(LoginActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
    }

    private void verifyRoleAndRedirect(String uid) {
        mDbRef.child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                progressDialog.dismiss();
                if (snapshot.exists()) {
                    String dbRole = snapshot.child("role").getValue(String.class);

                    if ("Admin".equals(dbRole)) {
                        startActivity(new Intent(LoginActivity.this, AdminActivity.class));
                    } else if ("Teacher".equals(dbRole)) {
                        startActivity(new Intent(LoginActivity.this, TeacherDashboardActivity.class));
                    } else if ("Student".equals(dbRole)) {
                        startActivity(new Intent(LoginActivity.this, MainActivity.class));
                    } else {
                        Toast.makeText(LoginActivity.this, "Unknown Role", Toast.LENGTH_SHORT).show();
                        mAuth.signOut();
                        return;
                    }
                    finish();
                } else {
                    progressDialog.dismiss();
                    // Basic fallback for manual admin bypass
                    if(mAuth.getCurrentUser() != null && mAuth.getCurrentUser().getEmail().contains("admin")) {
                        startActivity(new Intent(LoginActivity.this, AdminActivity.class));
                        finish();
                    } else {
                        Toast.makeText(LoginActivity.this, "Account not found in Database", Toast.LENGTH_SHORT).show();
                        mAuth.signOut();
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressDialog.dismiss();
                Toast.makeText(LoginActivity.this, "Database Error", Toast.LENGTH_SHORT).show();
            }
        });
    }
}