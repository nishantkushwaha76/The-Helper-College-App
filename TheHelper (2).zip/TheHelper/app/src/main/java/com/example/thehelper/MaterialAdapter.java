package com.example.thehelper;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class MaterialAdapter extends RecyclerView.Adapter<MaterialAdapter.ViewHolder> {

    private Context context;
    private List<UploadModel> uploadList;

    public MaterialAdapter(Context context, List<UploadModel> uploadList) {
        this.context = context;
        this.uploadList = uploadList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Connects to item_material.xml
        View view = LayoutInflater.from(context).inflate(R.layout.item_material, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        UploadModel upload = uploadList.get(position);

        // Set the file name
        holder.tvName.setText(upload.getName());

        // Handle click on the Download Icon
        holder.btnDownload.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(upload.getUrl()));
            context.startActivity(intent);
        });

        // Also open file if clicking anywhere on the card
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(upload.getUrl()));
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return uploadList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView tvName;
        ImageView btnDownload;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            // --- THE FIX IS HERE ---
            // Matches the ID in item_material.xml: android:id="@+id/tvMaterialName"
            tvName = itemView.findViewById(R.id.tvMaterialName);

            // Matches the ID in item_material.xml: android:id="@+id/btnDownloadMaterial"
            btnDownload = itemView.findViewById(R.id.btnDownloadMaterial);
        }
    }
}