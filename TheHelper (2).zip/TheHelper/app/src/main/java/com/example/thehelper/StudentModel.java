package com.example.thehelper;

public class StudentModel {

    // Public fields match the keys used in your Activity's updateMap
    public String uid;
    public String fullName;
    public String prn;
    public String branch;
    public String semester;
    public String division;
    public String roll;
    public String phone;
    public String email;
    private boolean present;

    // 1. REQUIRED empty constructor for Firebase DataSnapshot
    public StudentModel() {}

    // 2. Full Constructor used for creating new objects
    public StudentModel(String uid, String fullName, String prn, String branch,
                        String semester, String division, String roll,
                        String phone, String email) {
        this.uid = uid;
        this.fullName = fullName;
        this.prn = prn;
        this.branch = branch;
        this.semester = semester;
        this.division = division;
        this.roll = roll;
        this.phone = phone;
        this.email = email;
    }

    // --- GETTERS (Used by StudentDetailsActivity) ---
    public String getUid() { return uid; }
    public String getFullName() { return fullName; }
    public String getName() { return fullName; } // Compatibility alias
    public String getPrn() { return prn; }
    public String getBranch() { return branch; }
    public String getSemester() { return semester; }
    public String getDivision() { return division; }
    public String getRoll() { return roll; }
    public String getPhone() { return phone; }
    public String getEmail() { return email; }
    public boolean isPresent() { return present; }

    // --- SETTERS ---
    public void setPresent(boolean present) { this.present = present; }
    public void setUid(String uid) { this.uid = uid; }
}