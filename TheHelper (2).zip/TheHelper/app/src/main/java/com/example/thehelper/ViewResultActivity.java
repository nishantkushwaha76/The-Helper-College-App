package com.example.thehelper;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ViewResultActivity extends AppCompatActivity {

    private LinearLayout containerInternalMarks;
    private TextView tvNoMarks, tvNoImage;
    private Button btnViewOfficial;

    private DatabaseReference dbRef;
    private FirebaseAuth mAuth;
    private String studentPRN;
    private String officialUrl = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_result);

        mAuth = FirebaseAuth.getInstance();
        dbRef = FirebaseDatabase.getInstance().getReference();

        // Bind Views from the XML
        containerInternalMarks = findViewById(R.id.containerInternalMarks);
        tvNoMarks = findViewById(R.id.tvNoMarks);
        tvNoImage = findViewById(R.id.tvNoImage);
        btnViewOfficial = findViewById(R.id.btnViewOfficial);

        // Click Listener for Official Marksheet Button
        btnViewOfficial.setOnClickListener(v -> {
            if (!officialUrl.isEmpty()) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(officialUrl));
                startActivity(intent);
            } else {
                Toast.makeText(this, "No image link found", Toast.LENGTH_SHORT).show();
            }
        });

        loadStudentData();
    }

    private void loadStudentData() {
        if (mAuth.getCurrentUser() == null) return;
        String uid = mAuth.getCurrentUser().getUid();

        // 1. Get Student PRN from User Profile
        dbRef.child("Users").child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    studentPRN = snapshot.child("prn").getValue(String.class);
                    if (studentPRN != null) {
                        fetchResults(studentPRN);
                    } else {
                        Toast.makeText(ViewResultActivity.this, "PRN not found for this user", Toast.LENGTH_SHORT).show();
                    }
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void fetchResults(String prn) {
        DatabaseReference resultRef = dbRef.child("Results").child(prn);

        // A. Fetch Internal Marks (From Teachers)
        // Path: Results -> [PRN] -> Internal_Marks
        resultRef.child("Internal_Marks").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                containerInternalMarks.removeAllViews(); // Clear old list
                if (snapshot.exists()) {
                    tvNoMarks.setVisibility(View.GONE);

                    // Loop through every subject (e.g., "Mathematics", "Java")
                    for (DataSnapshot subjectSnap : snapshot.getChildren()) {
                        String subName = subjectSnap.getKey();

                        // Get marks safely
                        String ut1 = String.valueOf(subjectSnap.child("ut1").getValue());
                        String ut2 = String.valueOf(subjectSnap.child("ut2").getValue());

                        // Handle "null" strings
                        if(ut1.equals("null")) ut1 = "-";
                        if(ut2.equals("null")) ut2 = "-";

                        addSubjectRow(subName, ut1, ut2);
                    }
                } else {
                    tvNoMarks.setVisibility(View.VISIBLE);
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });

        // B. Fetch Official Marksheet Image (From Admin)
        // Path: Results -> [PRN] -> officialMarksheet
        resultRef.child("officialMarksheet").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    officialUrl = snapshot.getValue(String.class);
                    tvNoImage.setVisibility(View.GONE);
                    btnViewOfficial.setVisibility(View.VISIBLE);
                    btnViewOfficial.setText("View Official Marksheet");
                } else {
                    tvNoImage.setVisibility(View.VISIBLE);
                    btnViewOfficial.setVisibility(View.GONE);
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void addSubjectRow(String subject, String ut1, String ut2) {
        // Create a simple text view for each subject row dynamically
        TextView row = new TextView(this);

        String text = "📚 " + subject + "\n      UT1: " + ut1 + "/20   |   UT2: " + ut2 + "/20";

        row.setText(text);
        row.setTextSize(16f);
        row.setPadding(10, 10, 10, 25); // Add spacing
        row.setTextColor(getResources().getColor(android.R.color.black));

        containerInternalMarks.addView(row);

        // Add a divider line
        View divider = new View(this);
        divider.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 2));
        divider.setBackgroundColor(getResources().getColor(android.R.color.darker_gray));
        containerInternalMarks.addView(divider);
    }
}