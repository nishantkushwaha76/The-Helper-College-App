package com.example.thehelper;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SplashActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private static final int SPLASH_TIME_OUT = 2000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        mAuth = FirebaseAuth.getInstance();

        // Delay for 2 seconds then check status
        new Handler().postDelayed(this::checkUserStatus, SPLASH_TIME_OUT);
    }

    private void checkUserStatus() {
        FirebaseUser user = mAuth.getCurrentUser();

        if (user == null) {
            // 1. Not logged in -> Go to Login
            startActivity(new Intent(SplashActivity.this, LoginActivity.class));
            finish();
        } else {
            // 2. Logged in -> Check Role in Database
            checkUserRoleAndRedirect(user.getUid());
        }
    }

    private void checkUserRoleAndRedirect(String uid) {
        DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("Users").child(uid);

        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String role = snapshot.child("role").getValue(String.class);

                    if ("Admin".equals(role)) {
                        // Go to Admin Panel
                        startActivity(new Intent(SplashActivity.this, AdminActivity.class));
                    }
                    else if ("Teacher".equals(role)) {
                        // Go to Teacher Dashboard
                        startActivity(new Intent(SplashActivity.this, TeacherDashboardActivity.class));
                    }
                    else {
                        // Go to Student Dashboard (MainActivity)
                        // Note: We don't need StudentDetailsActivity anymore!
                        startActivity(new Intent(SplashActivity.this, MainActivity.class));
                    }
                    finish();
                } else {
                    // User data missing in DB -> Force re-login
                    mAuth.signOut();
                    startActivity(new Intent(SplashActivity.this, LoginActivity.class));
                    finish();
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                handleError();
            }
        });
    }

    private void handleError() {
        Toast.makeText(this, "Session expired. Please log in again.", Toast.LENGTH_LONG).show();
        mAuth.signOut();
        startActivity(new Intent(SplashActivity.this, LoginActivity.class));
        finish();
    }
}