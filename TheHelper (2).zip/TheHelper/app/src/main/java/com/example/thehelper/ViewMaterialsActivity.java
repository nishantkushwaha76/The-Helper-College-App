package com.example.thehelper;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.List;

public class ViewMaterialsActivity extends AppCompatActivity {

    private Spinner spCategory;
    private RecyclerView rvMaterials;
    private MaterialAdapter adapter;
    private List<UploadModel> uploadList;
    private DatabaseReference dbRef;
    private FirebaseAuth mAuth;
    private ProgressBar progressBar;
    private TextView tvNoData;

    private String studentBranchSemKey;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_materials);

        spCategory = findViewById(R.id.spStudentCategory);
        rvMaterials = findViewById(R.id.rvMaterials);
        progressBar = findViewById(R.id.pbMaterials);
        tvNoData = findViewById(R.id.tvNoMaterials);

        rvMaterials.setHasFixedSize(true);
        rvMaterials.setLayoutManager(new LinearLayoutManager(this));
        uploadList = new ArrayList<>();
        adapter = new MaterialAdapter(this, uploadList);
        rvMaterials.setAdapter(adapter);

        mAuth = FirebaseAuth.getInstance();

        setupCategorySpinner();

        // Start the new smart fetching logic
        fetchStudentInfoAndLoadData();

        spCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (studentBranchSemKey != null) {
                    loadMaterials();
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void setupCategorySpinner() {
        String[] categories = {
                "Notes", "Assignments", "Question Banks",
                "Exam Schedule", "Academic Calendar", "Result Sheet"
        };
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, categories);
        spCategory.setAdapter(spinnerAdapter);
    }

    // --- UPDATED: FIND PROFILE BY EXTRACTING PRN FROM EMAIL ---
    private void fetchStudentInfoAndLoadData() {
        FirebaseUser user = mAuth.getCurrentUser();
        if (user == null) return;

        String email = user.getEmail();
        if (email == null || !email.contains("@")) {
            Toast.makeText(this, "Invalid Email format", Toast.LENGTH_SHORT).show();
            return;
        }

        // Extract PRN from email (e.g. "2414110001@helper.com" -> "2414110001")
        String prn = email.split("@")[0];

        // Search in Students/[PRN] instead of Students/[UID]
        DatabaseReference studentRef = FirebaseDatabase.getInstance().getReference("Students").child(prn);

        studentRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String branch = snapshot.child("branch").getValue(String.class);
                    String rawSem = snapshot.child("semester").getValue(String.class);

                    if (branch != null && rawSem != null) {
                        // Clean the semester string (e.g. "Sem 3" -> "3")
                        String sem = rawSem.toLowerCase().replace("sem", "").replace(" ", "").trim();

                        // Create the key: CSE_3
                        studentBranchSemKey = branch + "_" + sem;

                        // Debug message to confirm success
                        Toast.makeText(ViewMaterialsActivity.this, "Loaded Profile: " + studentBranchSemKey, Toast.LENGTH_SHORT).show();
                        loadMaterials();
                    } else {
                        Toast.makeText(ViewMaterialsActivity.this, "Incomplete Profile Data", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // This error means the Admin hasn't added this PRN to the "Students" list yet
                    Toast.makeText(ViewMaterialsActivity.this, "Profile not found for PRN: " + prn, Toast.LENGTH_LONG).show();
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void loadMaterials() {
        if (studentBranchSemKey == null) return;

        progressBar.setVisibility(View.VISIBLE);
        tvNoData.setVisibility(View.GONE);

        String category = spCategory.getSelectedItem().toString();

        dbRef = FirebaseDatabase.getInstance().getReference("Materials")
                .child(studentBranchSemKey).child(category);

        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                uploadList.clear();
                for (DataSnapshot postSnapshot : snapshot.getChildren()) {
                    UploadModel upload = postSnapshot.getValue(UploadModel.class);
                    if (upload != null) {
                        uploadList.add(upload);
                    }
                }

                adapter.notifyDataSetChanged();
                progressBar.setVisibility(View.GONE);

                if (uploadList.isEmpty()) {
                    tvNoData.setVisibility(View.VISIBLE);
                    tvNoData.setText("No files in " + category);
                } else {
                    tvNoData.setVisibility(View.GONE);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                progressBar.setVisibility(View.GONE);
            }
        });
    }
}