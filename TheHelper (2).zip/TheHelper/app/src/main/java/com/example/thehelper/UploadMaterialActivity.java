package com.example.thehelper;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class UploadMaterialActivity extends AppCompatActivity {

    private Spinner spAssignedClass, spCategory;
    private EditText etFileName;
    private Button btnSelectFile, btnUpload, btnBack;
    private TextView tvFileStatus;

    private Uri pdfUri;
    private DatabaseReference dbRef;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_material);

        mAuth = FirebaseAuth.getInstance();
        dbRef = FirebaseDatabase.getInstance().getReference();

        // Bind Views
        spAssignedClass = findViewById(R.id.spBranchSem);
        spCategory = findViewById(R.id.spCategory);
        etFileName = findViewById(R.id.etFileName);
        btnSelectFile = findViewById(R.id.btnSelectFile);
        btnUpload = findViewById(R.id.btnUpload);
        tvFileStatus = findViewById(R.id.tvFileStatus);
        btnBack = findViewById(R.id.btnBackMaterial);

        setupCategorySpinner();
        loadTeacherAssignments(); // Fetches assigned classes dynamically

        btnSelectFile.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("application/pdf");
            startActivityForResult(Intent.createChooser(intent, "Select PDF"), 101);
        });

        // Calls the DEMO upload function (No Crash)
        btnUpload.setOnClickListener(v -> validateAndUploadDemo());
        btnBack.setOnClickListener(v -> finish());
    }

    private void setupCategorySpinner() {
        // Added "Result Sheet" to match Student App options
        String[] categories = {"Notes", "Assignments", "Question Banks", "Exam Schedule", "Academic Calendar", "Result Sheet"};
        spCategory.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, categories));
    }

    private void loadTeacherAssignments() {
        if (mAuth.getCurrentUser() == null) return;
        String uid = mAuth.getCurrentUser().getUid();

        // 1. Get Teacher PRN from User node
        dbRef.child("Users").child(uid).child("prn").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String prn = snapshot.getValue(String.class);
                if (prn != null) {
                    // 2. Get Assigned Subject Details from Teachers node
                    dbRef.child("Teachers").child(prn).addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot teacherSnap) {
                            if (teacherSnap.exists()) {
                                List<String> assignments = new ArrayList<>();
                                String branch = teacherSnap.child("branch").getValue(String.class);
                                String sem = teacherSnap.child("semester").getValue(String.class);
                                String sub = teacherSnap.child("subject").getValue(String.class);

                                // Format: "CSE_3 (Database Systems)"
                                // We will split this string later to extract "CSE_3"
                                String display = branch + "_" + sem + " (" + sub + ")";
                                assignments.add(display);

                                ArrayAdapter<String> adapter = new ArrayAdapter<>(UploadMaterialActivity.this,
                                        android.R.layout.simple_spinner_dropdown_item, assignments);
                                spAssignedClass.setAdapter(adapter);
                            } else {
                                Toast.makeText(UploadMaterialActivity.this, "No classes assigned. Contact Admin.", Toast.LENGTH_SHORT).show();
                            }
                        }
                        @Override public void onCancelled(@NonNull DatabaseError error) {}
                    });
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void validateAndUploadDemo() {
        if (pdfUri == null) {
            Toast.makeText(this, "Please select a PDF file first", Toast.LENGTH_SHORT).show();
            return;
        }
        if (etFileName.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "Please enter a file name", Toast.LENGTH_SHORT).show();
            return;
        }
        if (spAssignedClass.getSelectedItem() == null) {
            Toast.makeText(this, "No class selected", Toast.LENGTH_SHORT).show();
            return;
        }

        uploadFileDemoMode();
    }

    // --- DEMO MODE: SKIPS STORAGE UPLOAD TO AVOID 404 ---
    private void uploadFileDemoMode() {
        final ProgressDialog pd = new ProgressDialog(this);
        pd.setTitle("Uploading...");
        pd.setMessage("Processing (Demo Mode)");
        pd.show();

        new Handler().postDelayed(() -> {
            // 1. Extract the clean path key (e.g., "CSE_3")
            // Input: "CSE_3 (Database Systems)" -> Output: "CSE_3"
            String selected = spAssignedClass.getSelectedItem().toString();
            String pathKey = selected.split(" ")[0];

            String category = spCategory.getSelectedItem().toString();
            String fileName = etFileName.getText().toString().trim();

            // 2. Use a REAL dummy PDF link so the student app opens something valid
            String dummyUrl = "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf";

            // 3. Save to Database: Materials -> CSE_3 -> Notes
            UploadModel upload = new UploadModel(fileName, dummyUrl);

            dbRef.child("Materials").child(pathKey).child(category).push().setValue(upload)
                    .addOnSuccessListener(aVoid -> {
                        pd.dismiss();
                        Toast.makeText(this, "Uploaded Successfully!", Toast.LENGTH_SHORT).show();
                        finish();
                    })
                    .addOnFailureListener(e -> {
                        pd.dismiss();
                        Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });

        }, 1500); // Simulate network delay
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 101 && resultCode == RESULT_OK && data != null) {
            pdfUri = data.getData();
            tvFileStatus.setText("File Selected");
        }
    }
}