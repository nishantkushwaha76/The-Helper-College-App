package com.example.thehelper;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ProfileActivity extends AppCompatActivity {

    private TextView tvName, tvID, tvBranch, tvSemDiv, tvPersonalEmail, tvPhone, tvRoll;
    private TextView tvSubjects, tvSubjectsLabel; // Labels to hide/show

    private DatabaseReference mDbRef, subjectRef, teacherRef;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // Bind UI Components
        tvName = findViewById(R.id.tvProfileName);
        tvID = findViewById(R.id.tvProfileID);
        tvBranch = findViewById(R.id.tvProfileBranch);
        tvSemDiv = findViewById(R.id.tvProfileSemDiv);
        tvPersonalEmail = findViewById(R.id.tvProfileEmail);
        tvPhone = findViewById(R.id.tvProfilePhone);
        tvRoll = findViewById(R.id.tvProfileRoll);

        // Subject Section
        tvSubjects = findViewById(R.id.tvProfileSubjects);
        // We need to find the label "My Subjects" to hide it for teachers if needed
        // (If you didn't give the label an ID in XML, we can just hide the content)

        Button btnBack = findViewById(R.id.btnEditProfile);
        Button btnLogout = findViewById(R.id.btnLogoutProfile);

        mAuth = FirebaseAuth.getInstance();
        subjectRef = FirebaseDatabase.getInstance().getReference("Subjects");
        teacherRef = FirebaseDatabase.getInstance().getReference("Teachers");

        if (mAuth.getCurrentUser() != null) {
            String currentUid = mAuth.getCurrentUser().getUid();
            mDbRef = FirebaseDatabase.getInstance().getReference("Users").child(currentUid);
            loadProfileData();
        }

        btnBack.setOnClickListener(v -> finish());

        if (btnLogout != null) {
            btnLogout.setOnClickListener(v -> {
                mAuth.signOut();
                Intent intent = new Intent(ProfileActivity.this, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            });
        }
    }

    private void loadProfileData() {
        mDbRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String role = snapshot.child("role").getValue(String.class);
                    String name = snapshot.child("fullName").getValue(String.class);
                    String prn = snapshot.child("prn").getValue(String.class); // ID
                    String branch = snapshot.child("branch").getValue(String.class);
                    String sem = snapshot.child("semester").getValue(String.class);
                    String div = snapshot.child("division").getValue(String.class);
                    String phone = snapshot.child("phone").getValue(String.class);
                    String pEmail = snapshot.child("personalEmail").getValue(String.class);

                    // --- COMMON DATA (For Both) ---
                    tvName.setText(name);
                    tvPersonalEmail.setText("Email: " + (pEmail != null ? pEmail : "N/A"));
                    tvPhone.setText("Phone: " + (phone != null ? phone : "N/A"));

                    // --- ROLE SPECIFIC LOGIC ---
                    if ("Teacher".equals(role)) {
                        // TEACHER VIEW
                        tvID.setText("Teacher ID: " + prn);
                        tvRoll.setVisibility(View.GONE); // Teachers don't have roll numbers

                        // Show GFM Info
                        tvBranch.setText("Department: " + branch);
                        tvSemDiv.setText("GFM of Class: " + branch + " - Sem " + sem + " (" + div + ")");

                        // Fetch the specific subject they teach
                        fetchTeacherSubject(prn);

                    } else {
                        // STUDENT VIEW
                        String roll = snapshot.child("roll").getValue(String.class);
                        tvID.setText("PRN: " + prn);
                        tvRoll.setVisibility(View.VISIBLE);
                        tvRoll.setText("Roll No: " + (roll != null ? roll : "N/A"));

                        tvBranch.setText("Branch: " + branch);
                        tvSemDiv.setText("Sem: " + sem + " | Div: " + div);

                        // Load all subjects for the semester
                        if (branch != null && sem != null) {
                            loadStudentSubjects(branch, sem);
                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ProfileActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Load list of all subjects (For Students)
    private void loadStudentSubjects(String branch, String sem) {
        String key = branch + "_SEM " + sem;
        subjectRef.child(key).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    StringBuilder sb = new StringBuilder();
                    int count = 1;
                    for (DataSnapshot sub : snapshot.getChildren()) {
                        String subjectName = sub.getValue(String.class);
                        if(subjectName != null) {
                            sb.append(count).append(". ").append(subjectName).append("\n");
                            count++;
                        }
                    }
                    tvSubjects.setText(sb.toString().trim());
                } else {
                    tvSubjects.setText("No subjects found.");
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    // Fetch the single subject the Teacher is assigned to
    private void fetchTeacherSubject(String teacherId) {
        teacherRef.child(teacherId).child("subject").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String sub = snapshot.getValue(String.class);
                    // We reuse the subject text view to show their assigned subject
                    tvSubjects.setText("Assigned Subject: " + (sub != null ? sub : "General"));
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }
}