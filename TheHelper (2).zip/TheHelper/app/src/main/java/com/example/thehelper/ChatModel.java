package com.example.thehelper;

public class ChatModel {
    private String senderName;
    private String message;
    private String senderRole;
    private String senderUid;
    private long timestamp;
    private String type;       // "text" or "image"
    private String imageUrl;

    // Required empty constructor
    public ChatModel() { }

    public ChatModel(String senderName, String message, String senderRole, String senderUid, long timestamp, String type, String imageUrl) {
        this.senderName = senderName;
        this.message = message;
        this.senderRole = senderRole;
        this.senderUid = senderUid;
        this.timestamp = timestamp;
        this.type = type;
        this.imageUrl = imageUrl;
    }

    // Getters
    public String getSenderName() { return senderName; }
    public String getMessage() { return message; }
    public String getSenderRole() { return senderRole; }
    public String getSenderUid() { return senderUid; }
    public long getTimestamp() { return timestamp; }
    public String getType() { return type; }
    public String getImageUrl() { return imageUrl; }

    // Setters (Good practice for Firebase)
    public void setSenderName(String senderName) { this.senderName = senderName; }
    public void setMessage(String message) { this.message = message; }
    public void setSenderRole(String senderRole) { this.senderRole = senderRole; }
    public void setSenderUid(String senderUid) { this.senderUid = senderUid; }
    public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
    public void setType(String type) { this.type = type; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
}