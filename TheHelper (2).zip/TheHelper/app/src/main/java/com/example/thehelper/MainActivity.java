package com.example.thehelper;

import android.Manifest; // --- ADDED THIS
import android.content.Intent;
import android.content.pm.PackageManager; // --- ADDED THIS
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Build; // --- ADDED THIS
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat; // --- ADDED THIS
import androidx.core.content.ContextCompat; // --- ADDED THIS
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.messaging.FirebaseMessaging; // --- ADDED THIS
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    // Views
    private TextView tvName, tvDayTitle, tvLiveTimetable;

    // Exam Alert Views
    private CardView cardExamAlertDisplay;
    private TextView tvExamSubject, tvExamDetails;

    // Chat Container
    private LinearLayout subjectChatContainer;

    private Button btnLogout;
    private CardView cardAttendance, cardResults, cardMaterials, cardNotices, cardProfile, cardChat;

    // Firebase
    private FirebaseAuth mAuth;
    private DatabaseReference dbRef;

    // Student Data
    private String myBranch, mySem, myDiv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // --- 1. ASK FOR NOTIFICATION PERMISSION (REQUIRED FOR ANDROID 13+) ---
        askNotificationPermission();

        // Optional: Log token to see if FCM is working
        FirebaseMessaging.getInstance().getToken().addOnSuccessListener(token -> {
            Log.d("FCM_TOKEN", "Your Device Token: " + token);
        });

        mAuth = FirebaseAuth.getInstance();
        dbRef = FirebaseDatabase.getInstance().getReference();

        // 2. Bind Views
        tvName = findViewById(R.id.tvStudentName);
        tvDayTitle = findViewById(R.id.tvDayTitle);
        tvLiveTimetable = findViewById(R.id.tvLiveTimetable);
        btnLogout = findViewById(R.id.btnLogout);

        // Bind Chat Container
        subjectChatContainer = findViewById(R.id.subjectChatContainer);

        // Dashboard Cards
        cardAttendance = findViewById(R.id.cardViewAttendance);
        cardResults = findViewById(R.id.cardViewResult);
        cardMaterials = findViewById(R.id.cardViewMaterials);
        cardNotices = findViewById(R.id.cardNoticeBoard);
        cardProfile = findViewById(R.id.cardProfile);
        cardChat = findViewById(R.id.cardChat);

        // Bind Exam Alert Card
        cardExamAlertDisplay = findViewById(R.id.cardExamAlertDisplay);
        tvExamSubject = findViewById(R.id.tvExamSubject);
        tvExamDetails = findViewById(R.id.tvExamDetails);

        // 3. Check User & Load Data
        checkUserAndLoadData();

        // 4. Set Click Listeners
        setupClickListeners();
    }

    // --- NEW METHOD: THIS WAS MISSING IN YOUR CODE ---
    private void askNotificationPermission() {
        // This is only necessary for API level >= 33 (Android 13 - Tiramisu)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
                    PackageManager.PERMISSION_GRANTED) {
                // Directly ask for the permission
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
            }
        }
    }

    private void setupClickListeners() {
        cardAttendance.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, ViewAttendanceActivity.class)));
        cardResults.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, ViewResultActivity.class)));
        cardMaterials.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, ViewMaterialsActivity.class)));
        cardNotices.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, ViewNoticeActivity.class)));
        cardProfile.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, ProfileActivity.class)));

        // Grid Shortcut
        cardChat.setOnClickListener(v -> {
            if (myBranch != null && mySem != null) {
                joinChat("Common Class", true);
            } else {
                Toast.makeText(this, "Loading class info...", Toast.LENGTH_SHORT).show();
            }
        });

        btnLogout.setOnClickListener(v -> {
            mAuth.signOut();
            Intent intent = new Intent(this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    private void checkUserAndLoadData() {
        if (mAuth.getCurrentUser() == null) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        String uid = mAuth.getCurrentUser().getUid();

        dbRef.child("Users").child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String role = snapshot.child("role").getValue(String.class);

                    if ("Admin".equals(role)) {
                        startActivity(new Intent(MainActivity.this, AdminActivity.class));
                        finish();
                        return;
                    } else if ("Teacher".equals(role)) {
                        startActivity(new Intent(MainActivity.this, TeacherDashboardActivity.class));
                        finish();
                        return;
                    }

                    // Student Data Loading
                    String name = snapshot.child("name").getValue(String.class);
                    if (name == null) name = snapshot.child("fullName").getValue(String.class);
                    tvName.setText("Welcome, " + (name != null ? name : "Student"));

                    myBranch = snapshot.child("branch").getValue(String.class);
                    mySem = snapshot.child("semester").getValue(String.class);
                    myDiv = snapshot.child("division").getValue(String.class);

                    // If data is ready, load everything
                    if (myBranch != null && mySem != null) {
                        loadLiveTimetable(myBranch, mySem, myDiv);
                        checkUpcomingExams(myBranch, mySem);
                        loadSubjectChats(myBranch, mySem);
                    }
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    // --- CHAT LOGIC ---
    private void loadSubjectChats(String branch, String sem) {
        if (subjectChatContainer == null) return;
        subjectChatContainer.removeAllViews();

        // 1. Common Class Button
        createChatButton("📢 Common Class (" + branch + " " + sem + ")", true);

        // 2. Dynamic Subject Buttons
        String key = branch + "_SEM " + sem;
        dbRef.child("Subjects").child(key).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    for (DataSnapshot subSnap : snapshot.getChildren()) {
                        String subjectName = subSnap.getValue(String.class);
                        if(subjectName != null) {
                            createChatButton(subjectName, false);
                        }
                    }
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void createChatButton(String subject, boolean isCommon) {
        Button btn = new Button(this);
        btn.setText(isCommon ? subject : "💬 Chat: " + subject);

        if (isCommon) {
            btn.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#E91E63"))); // Pink
        } else {
            btn.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#673AB7"))); // Purple
        }

        btn.setTextColor(Color.WHITE);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 8, 0, 8);
        btn.setLayoutParams(params);

        btn.setOnClickListener(v -> joinChat(subject, isCommon));

        subjectChatContainer.addView(btn);
    }

    private void joinChat(String subjectName, boolean isCommon) {
        String div = (myDiv != null) ? myDiv : "A";
        String roomId;
        String title;

        if (isCommon) {
            roomId = myBranch + "_" + mySem + "_" + div + "_Common_Class";
            title = "Common Class";
        } else {
            String cleanName = subjectName.replace("💬 Chat: ", "");
            String safeSubject = cleanName.replace(" ", "_");
            roomId = myBranch + "_" + mySem + "_" + div + "_" + safeSubject;
            title = cleanName + " Chat";
        }

        Intent intent = new Intent(MainActivity.this, ChatActivity.class);
        intent.putExtra("ROOM_ID", roomId);
        intent.putExtra("TITLE", title);
        startActivity(intent);
    }

    // --- TIMETABLE LOGIC ---
    private void loadLiveTimetable(String branch, String sem, String div) {
        if (div == null || div.isEmpty()) div = "A";
        String path = branch + "_" + sem + "_" + div;
        String[] days = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
        Calendar calendar = Calendar.getInstance();
        String todayStr = days[calendar.get(Calendar.DAY_OF_WEEK) - 1];

        tvDayTitle.setText(todayStr + "'s Schedule");

        dbRef.child("Timetable").child(path).child(todayStr).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    StringBuilder builder = new StringBuilder();
                    for (DataSnapshot slot : snapshot.getChildren()) {
                        String time = slot.getKey();
                        String subject = slot.getValue(String.class);
                        builder.append("⏰ ").append(time).append(" : ").append(subject).append("\n\n");
                    }
                    tvLiveTimetable.setText(builder.toString().trim());
                } else {
                    tvLiveTimetable.setText("No classes scheduled for today.");
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    // --- EXAM LOGIC ---
    private void checkUpcomingExams(String branch, String sem) {
        String path = branch + "_" + sem;
        String todayDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        dbRef.child("Exams").child(path).orderByKey().startAt(todayDate).limitToFirst(1)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            for (DataSnapshot examSnap : snapshot.getChildren()) {
                                String date = examSnap.getKey();
                                String subject = examSnap.child("subject").getValue(String.class);
                                String time = examSnap.child("time").getValue(String.class);
                                String duration = examSnap.child("duration").getValue(String.class);

                                if (subject != null) {
                                    cardExamAlertDisplay.setVisibility(View.VISIBLE);
                                    tvExamSubject.setText(subject);
                                    tvExamDetails.setText("📅 " + date + "  ⏰ " + time + " (" + duration + ")");
                                }
                            }
                        } else {
                            cardExamAlertDisplay.setVisibility(View.GONE);
                        }
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {}
                });
    }
}