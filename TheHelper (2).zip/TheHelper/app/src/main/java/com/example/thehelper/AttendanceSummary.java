package com.example.thehelper;

public class AttendanceSummary {

    // Making fields private is best practice (encapsulation)
    private int attended;
    private int total;

    // Required default constructor for Firebase
    public AttendanceSummary() { }

    // Full constructor
    public AttendanceSummary(int attended, int total) {
        this.attended = attended;
        this.total = total;
    }

    // --- Getters ---
    public int getAttended() {
        return attended;
    }

    public int getTotal() {
        return total;
    }

    // --- Setters ---
    public void setAttended(int attended) {
        this.attended = attended;
    }

    public void setTotal(int total) {
        this.total = total;
    }
}