package com.example.thehelper;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;

public class ViewAttendanceActivity extends AppCompatActivity {

    private TextView tvOverallPercentage, tvTotalLectures, tvTotalPresent;
    private ListView lvSubjectAttendance;

    private DatabaseReference dbRef;
    private FirebaseAuth mAuth;
    private String studentPRN, studentBranch, studentSem, studentDiv;

    // List to hold data for your Custom Cards
    private ArrayList<SubjectModel> subjectList;
    private AttendanceAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_attendance);

        // Bind Views
        tvOverallPercentage = findViewById(R.id.tvOverallPercentage);
        tvTotalLectures = findViewById(R.id.tvTotalLectures);
        tvTotalPresent = findViewById(R.id.tvTotalPresent);
        lvSubjectAttendance = findViewById(R.id.lvSubjectAttendance);

        subjectList = new ArrayList<>();
        adapter = new AttendanceAdapter();
        lvSubjectAttendance.setAdapter(adapter);

        mAuth = FirebaseAuth.getInstance();
        dbRef = FirebaseDatabase.getInstance().getReference();

        loadStudentProfile();
    }

    private void loadStudentProfile() {
        if (mAuth.getCurrentUser() == null) return;
        String uid = mAuth.getCurrentUser().getUid();

        dbRef.child("Users").child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    studentPRN = snapshot.child("prn").getValue(String.class);
                    studentBranch = snapshot.child("branch").getValue(String.class);
                    studentSem = snapshot.child("semester").getValue(String.class);
                    studentDiv = snapshot.child("division").getValue(String.class);

                    if (studentPRN != null) {
                        calculateAttendance();
                    }
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void calculateAttendance() {
        // Path: Attendance -> [Branch]_[Sem]_[Div]
        String classKey = studentBranch + "_" + studentSem + "_" + studentDiv;
        DatabaseReference attRef = dbRef.child("Attendance").child(classKey);

        attRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                subjectList.clear();
                int grandTotalLectures = 0;
                int grandTotalPresent = 0;

                // Loop through Subjects (e.g., "Maths", "Java")
                for (DataSnapshot subjectSnap : snapshot.getChildren()) {
                    String subjectName = subjectSnap.getKey();
                    int subjectTotal = 0;
                    int subjectPresent = 0;

                    // Loop through Dates
                    for (DataSnapshot dateSnap : subjectSnap.getChildren()) {
                        if (dateSnap.hasChild(studentPRN)) {
                            subjectTotal++;
                            String status = dateSnap.child(studentPRN).getValue(String.class);
                            if ("Present".equals(status)) {
                                subjectPresent++;
                            }
                        }
                    }

                    // Calculate Subject %
                    float subPercent = 0;
                    if (subjectTotal > 0) {
                        subPercent = ((float) subjectPresent / subjectTotal) * 100;
                    }

                    // Add to list for the Custom Card
                    subjectList.add(new SubjectModel(subjectName, subjectPresent, subjectTotal, subPercent));

                    // Add to Overall Totals
                    grandTotalLectures += subjectTotal;
                    grandTotalPresent += subjectPresent;
                }

                // Update Overall Header
                float overallPercent = 0;
                if (grandTotalLectures > 0) {
                    overallPercent = ((float) grandTotalPresent / grandTotalLectures) * 100;
                }

                tvOverallPercentage.setText(String.format("%.1f%%", overallPercent));
                tvTotalLectures.setText("Total Lectures: " + grandTotalLectures);
                tvTotalPresent.setText("Attended: " + grandTotalPresent);

                // Refresh the List of Cards
                adapter.notifyDataSetChanged();

                if (overallPercent >= 75) tvOverallPercentage.setTextColor(Color.parseColor("#4CAF50")); // Green
                else tvOverallPercentage.setTextColor(Color.RED);
            }

            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    // --- 1. Data Model for the Card ---
    class SubjectModel {
        String name;
        int present, total;
        float percent;

        public SubjectModel(String name, int present, int total, float percent) {
            this.name = name;
            this.present = present;
            this.total = total;
            this.percent = percent;
        }
    }

    // --- 2. Custom Adapter to link Java to your XML ---
    class AttendanceAdapter extends BaseAdapter {
        @Override
        public int getCount() { return subjectList.size(); }
        @Override
        public Object getItem(int i) { return subjectList.get(i); }
        @Override
        public long getItemId(int i) { return i; }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            if (view == null) {
                // This line inflates your CUSTOM XML file
                view = LayoutInflater.from(ViewAttendanceActivity.this).inflate(R.layout.item_subject_attendance, viewGroup, false);
            }

            // Bind Views from your XML
            TextView tvSub = view.findViewById(R.id.tvSubjectName);
            TextView tvPerc = view.findViewById(R.id.tvPercentage);
            TextView tvAttended = view.findViewById(R.id.tvAttendedClasses);
            ProgressBar pb = view.findViewById(R.id.pbAttendance);

            SubjectModel s = subjectList.get(i);

            // Set Data
            tvSub.setText(s.name);
            tvPerc.setText(String.format("%.1f%%", s.percent));
            tvAttended.setText("Attended: " + s.present + "/" + s.total);

            pb.setProgress((int) s.percent);

            // Change Color based on Percentage
            if (s.percent >= 75) {
                tvPerc.setTextColor(Color.parseColor("#4CAF50")); // Green
                pb.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#4CAF50")));
            } else {
                tvPerc.setTextColor(Color.parseColor("#F44336")); // Red
                pb.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#F44336")));
            }

            return view;
        }
    }
}