package com.example.thehelper;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class TeacherAttendanceActivity extends AppCompatActivity {

    private TextView tvClassInfo, tvDate;
    private ListView lvStudents;
    private Button btnSubmit;
    private DatabaseReference dbRef;
    private FirebaseAuth mAuth;

    // Teacher's assigned details (Locked from DB)
    private String tBranch, tSem, tDiv, tSubject;

    // Data for the list
    private ArrayList<StudentModel> studentList;
    private AttendanceAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_attendance); // Ensures it uses the secure XML

        dbRef = FirebaseDatabase.getInstance().getReference();
        mAuth = FirebaseAuth.getInstance();

        // Bind Views (Matches the secure XML)
        tvClassInfo = findViewById(R.id.tvAttClassInfo);
        tvDate = findViewById(R.id.tvAttDate);
        lvStudents = findViewById(R.id.lvAttendanceStudents);
        btnSubmit = findViewById(R.id.btnSubmitAttendance);

        studentList = new ArrayList<>();
        adapter = new AttendanceAdapter();
        lvStudents.setAdapter(adapter);

        // Auto-set Date
        String currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        tvDate.setText("Date: " + currentDate);

        // Start Logic: Load Teacher -> Load Assignment -> Load Students
        loadTeacherInfo();

        btnSubmit.setOnClickListener(v -> saveAttendance(currentDate));
    }

    private void loadTeacherInfo() {
        if (mAuth.getCurrentUser() == null) return;
        String uid = mAuth.getCurrentUser().getUid();

        // 1. Get Teacher's PRN from their Profile
        dbRef.child("Users").child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String tid = snapshot.child("prn").getValue(String.class);
                    if (tid != null) fetchAssignment(tid);
                    else Toast.makeText(TeacherAttendanceActivity.this, "Error: Teacher PRN not found", Toast.LENGTH_SHORT).show();
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void fetchAssignment(String tid) {
        // 2. Get the Class Assigned to this Teacher
        dbRef.child("Teachers").child(tid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    tBranch = snapshot.child("branch").getValue(String.class);
                    tSem = snapshot.child("semester").getValue(String.class);
                    tDiv = snapshot.child("division").getValue(String.class);
                    tSubject = snapshot.child("subject").getValue(String.class);

                    // Display Locked Info
                    tvClassInfo.setText("Class: " + tBranch + " (Sem " + tSem + ") - Div " + tDiv + "\nSubject: " + tSubject);

                    // 3. Fetch Students for this specific class
                    fetchStudents();
                } else {
                    tvClassInfo.setText("No class assigned. Contact Admin.");
                    btnSubmit.setEnabled(false);
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void fetchStudents() {
        // Query Students based on Branch
        dbRef.child("Students").orderByChild("branch").equalTo(tBranch)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        studentList.clear();
                        for (DataSnapshot s : snapshot.getChildren()) {
                            // Filter specifically for Semester and Division
                            String sem = s.child("semester").getValue(String.class);
                            String div = s.child("division").getValue(String.class);

                            if (sem != null && sem.equals(tSem) && div != null && div.equals(tDiv)) {
                                String name = s.child("name").getValue(String.class);
                                String prn = s.getKey(); // PRN is the Key
                                studentList.add(new StudentModel(name, prn, true)); // Default Present
                            }
                        }
                        adapter.notifyDataSetChanged();

                        if (studentList.isEmpty()) {
                            Toast.makeText(TeacherAttendanceActivity.this, "No students found in this class.", Toast.LENGTH_SHORT).show();
                        }
                    }
                    @Override public void onCancelled(@NonNull DatabaseError error) {}
                });
    }

    private void saveAttendance(String date) {
        if (studentList.isEmpty()) return;

        // Path: Attendance -> [Branch_Sem_Div] -> [Subject] -> [Date] -> [PRN]
        String classKey = tBranch + "_" + tSem + "_" + tDiv;
        DatabaseReference attRef = dbRef.child("Attendance").child(classKey).child(tSubject).child(date);

        for (StudentModel s : studentList) {
            String status = s.isPresent ? "Present" : "Absent";
            attRef.child(s.prn).setValue(status);
        }

        Toast.makeText(this, "Attendance Saved Successfully!", Toast.LENGTH_SHORT).show();
        finish();
    }

    // --- Inner Class for Student Data ---
    class StudentModel {
        String name, prn;
        boolean isPresent;

        public StudentModel(String name, String prn, boolean isPresent) {
            this.name = name;
            this.prn = prn;
            this.isPresent = isPresent;
        }
    }

    // --- Inner Class for Adapter ---
    class AttendanceAdapter extends BaseAdapter {
        @Override
        public int getCount() { return studentList.size(); }
        @Override
        public Object getItem(int i) { return studentList.get(i); }
        @Override
        public long getItemId(int i) { return i; }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            if (view == null) {
                view = LayoutInflater.from(TeacherAttendanceActivity.this).inflate(R.layout.item_student_attendance, viewGroup, false);
            }

            TextView name = view.findViewById(R.id.tvStudentName);
            TextView prn = view.findViewById(R.id.tvStudentPRN);
            CheckBox cb = view.findViewById(R.id.cbPresent);

            StudentModel s = studentList.get(i);

            name.setText(s.name);
            prn.setText(s.prn);

            // Prevent listener conflicts during scroll
            cb.setOnCheckedChangeListener(null);
            cb.setChecked(s.isPresent);
            cb.setOnCheckedChangeListener((buttonView, isChecked) -> s.isPresent = isChecked);

            return view;
        }
    }
}