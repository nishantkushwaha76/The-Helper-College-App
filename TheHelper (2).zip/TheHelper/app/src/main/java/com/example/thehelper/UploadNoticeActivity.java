package com.example.thehelper;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class UploadNoticeActivity extends AppCompatActivity { // Class name matches file name

    private EditText etTitle, etMessage;
    private Button btnUpload;
    private DatabaseReference dbRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_notice);

        // Database Path: "Notices"
        dbRef = FirebaseDatabase.getInstance().getReference("Notices");

        // Bind Views
        etTitle = findViewById(R.id.etNoticeTitle);
        etMessage = findViewById(R.id.etNoticeDesc);
        btnUpload = findViewById(R.id.btnUploadNotice);

        btnUpload.setOnClickListener(v -> uploadNotice());
    }

    private void uploadNotice() {
        String title = etTitle.getText().toString().trim();
        String message = etMessage.getText().toString().trim();

        if (TextUtils.isEmpty(title) || TextUtils.isEmpty(message)) {
            Toast.makeText(this, "Please enter title and message", Toast.LENGTH_SHORT).show();
            return;
        }

        // Get Current Date
        String date = new SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault()).format(new Date());

        // Generate Unique ID
        String id = dbRef.push().getKey();

        // Create Model
        NoticeModel notice = new NoticeModel(title, message, date);

        // Save to Firebase
        if (id != null) {
            dbRef.child(id).setValue(notice).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    Toast.makeText(UploadNoticeActivity.this, "Notice Posted Successfully!", Toast.LENGTH_SHORT).show();
                    finish(); // Go back
                } else {
                    Toast.makeText(UploadNoticeActivity.this, "Failed to post notice.", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}