package com.example.thehelper;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class UploadMarksActivity extends AppCompatActivity {

    private TextView tvSubjectInfo;
    private EditText etPrn, etUt1, etUt2;
    private Button btnUpload, btnBack;
    private DatabaseReference dbRef;

    // Variables to hold the teacher's assigned details
    private String assignedSubject, assignedBranch, assignedSem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_marks);

        dbRef = FirebaseDatabase.getInstance().getReference("Results");

        // 1. Get Data from Teacher Dashboard
        assignedSubject = getIntent().getStringExtra("SUBJECT");
        assignedBranch = getIntent().getStringExtra("BRANCH");
        assignedSem = getIntent().getStringExtra("SEM");

        // Bind Views
        tvSubjectInfo = findViewById(R.id.tvSubjectInfo);
        etPrn = findViewById(R.id.etMarkStudentPRN);
        etUt1 = findViewById(R.id.etMarksUT1);
        etUt2 = findViewById(R.id.etMarksUT2);
        btnUpload = findViewById(R.id.btnSubmitMarks);
        btnBack = findViewById(R.id.btnBackFromMarks);

        // 2. Display the Subject Info (So teacher knows what they are uploading for)
        if (assignedSubject != null) {
            tvSubjectInfo.setText("Uploading Internal Marks for:\n" + assignedSubject + "\n(" + assignedBranch + " - Sem " + assignedSem + ")");
        } else {
            tvSubjectInfo.setText("Error: No Subject Assigned");
            btnUpload.setEnabled(false); // Prevent upload if subject is missing
        }

        btnUpload.setOnClickListener(v -> uploadMarksLogic());
        btnBack.setOnClickListener(v -> finish());
    }

    private void uploadMarksLogic() {
        String prn = etPrn.getText().toString().trim();
        String u1Str = etUt1.getText().toString().trim();
        String u2Str = etUt2.getText().toString().trim();

        // Basic Validation
        if (TextUtils.isEmpty(prn) || TextUtils.isEmpty(u1Str) || TextUtils.isEmpty(u2Str)) {
            Toast.makeText(this, "Please fill PRN and both UT marks", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int ut1 = Integer.parseInt(u1Str);
            int ut2 = Integer.parseInt(u2Str);

            // Logic Validation: UT Marks cannot be > 20
            if(ut1 > 20 || ut2 > 20) {
                Toast.makeText(this, "Unit Test marks cannot exceed 20!", Toast.LENGTH_LONG).show();
                return;
            }

            // Save to Database: Results -> [PRN] -> Internal_Marks -> [Subject]
            DatabaseReference internalRef = dbRef.child(prn).child("Internal_Marks").child(assignedSubject);

            internalRef.child("ut1").setValue(String.valueOf(ut1));
            internalRef.child("ut2").setValue(String.valueOf(ut2))
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, "Marks saved for PRN: " + prn, Toast.LENGTH_SHORT).show();
                        clearFields();
                    })
                    .addOnFailureListener(e -> Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Marks must be valid numbers", Toast.LENGTH_SHORT).show();
        }
    }

    private void clearFields() {
        etPrn.setText("");
        etUt1.setText("");
        etUt2.setText("");
        etPrn.requestFocus(); // Move cursor back to PRN for the next student
    }
}