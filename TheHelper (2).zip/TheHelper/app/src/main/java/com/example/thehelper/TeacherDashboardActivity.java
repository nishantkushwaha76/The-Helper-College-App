package com.example.thehelper;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.Calendar;

public class TeacherDashboardActivity extends AppCompatActivity {

    private TextView tvWelcome, tvDay, tvTimetable;
    private LinearLayout classroomContainer;

    // --- UPDATED: Added 'cardNotice' to the list ---
    private CardView cardMarkAttendance, cardUploadMaterials, cardUploadMarks, cardNotice, cardProfile;

    private Button btnLogout;
    private ProgressBar progressBar;
    private FirebaseAuth mAuth;
    private DatabaseReference dbRef;

    // Global variables to store the Teacher's Assignment
    private String myBranch, mySem, mySubject;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_dashboard);

        mAuth = FirebaseAuth.getInstance();
        dbRef = FirebaseDatabase.getInstance().getReference();

        // Bind Views
        tvWelcome = findViewById(R.id.tvWelcomeTeacher);
        tvDay = findViewById(R.id.tvTeacherDay);
        tvTimetable = findViewById(R.id.tvTeacherTimetable);
        classroomContainer = findViewById(R.id.classroomContainer);
        progressBar = findViewById(R.id.pbTeacherDashboard);
        btnLogout = findViewById(R.id.btnLogoutTeacher); // Make sure this matches XML ID

        // Bind Cards
        cardMarkAttendance = findViewById(R.id.cardTeacherAttendance);
        cardUploadMaterials = findViewById(R.id.cardTeacherMaterials);
        cardUploadMarks = findViewById(R.id.cardTeacherMarks);

        // --- NEW: Bind the Notice Card ---
        cardNotice = findViewById(R.id.cardTeacherNotice);

        cardProfile = findViewById(R.id.cardTeacherProfile);

        setupNavigation();
        loadTeacherData();
    }

    private void setupNavigation() {
        // 1. Attendance
        cardMarkAttendance.setOnClickListener(v ->
                startActivity(new Intent(this, TeacherAttendanceActivity.class)));

        // 2. Materials
        cardUploadMaterials.setOnClickListener(v ->
                startActivity(new Intent(this, UploadMaterialActivity.class)));

        // 3. Upload Marks (Passes Subject Info safely)
        cardUploadMarks.setOnClickListener(v -> {
            if (mySubject == null || myBranch == null) {
                Toast.makeText(this, "Fetching your subject details... please wait.", Toast.LENGTH_SHORT).show();
            } else {
                Intent intent = new Intent(this, UploadMarksActivity.class);
                intent.putExtra("BRANCH", myBranch);
                intent.putExtra("SEM", mySem);
                intent.putExtra("SUBJECT", mySubject);
                startActivity(intent);
            }
        });

        // 4. --- NEW: UPLOAD NOTICE ---
        if (cardNotice != null) {
            cardNotice.setOnClickListener(v ->
                    startActivity(new Intent(TeacherDashboardActivity.this, UploadNoticeActivity.class)));
        }

        // 5. Open Profile
        if (cardProfile != null) {
            cardProfile.setOnClickListener(v ->
                    startActivity(new Intent(this, TeacherProfileActivity.class)));
        }

        // 6. Logout
        btnLogout.setOnClickListener(v -> {
            mAuth.signOut();
            Intent intent = new Intent(this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    private void loadTeacherData() {
        if (mAuth.getCurrentUser() == null) return;
        if (progressBar != null) progressBar.setVisibility(View.VISIBLE);

        String uid = mAuth.getCurrentUser().getUid();

        dbRef.child("Users").child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    // Try to get 'name' first, if null try 'fullName'
                    String name = snapshot.child("name").getValue(String.class);
                    if (name == null) name = snapshot.child("fullName").getValue(String.class);

                    tvWelcome.setText("Welcome, " + (name != null ? name : "Teacher"));

                    // Get the unique Teacher ID (PRN) to find assignments
                    String teacherID = snapshot.child("prn").getValue(String.class);

                    if (teacherID != null) {
                        fetchAssignments(teacherID);
                    } else {
                        showError("Error: Teacher ID not found.");
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                if (progressBar != null) progressBar.setVisibility(View.GONE);
            }
        });

        loadLiveSchedule(uid);
    }

    private void fetchAssignments(String tid) {
        dbRef.child("Teachers").child(tid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (classroomContainer != null) classroomContainer.removeAllViews();

                if (snapshot.exists()) {
                    // SAVE DATA GLOBALLY for the Upload Marks Screen
                    myBranch = snapshot.child("branch").getValue(String.class);
                    mySem = snapshot.child("semester").getValue(String.class);
                    mySubject = snapshot.child("subject").getValue(String.class);
                    String div = snapshot.child("division").getValue(String.class);

                    div = (div != null) ? div : "A";
                    mySubject = (mySubject != null) ? mySubject : "General";

                    if (myBranch != null && mySem != null) {
                        // 1. Common Room Button
                        createClassButton(myBranch, mySem, div, "Common Class");
                        // 2. Specific Subject Room Button
                        createClassButton(myBranch, mySem, div, mySubject);
                    } else {
                        showError("No classes assigned yet.");
                    }
                } else {
                    showError("ID " + tid + " not assigned.");
                }
                if (progressBar != null) progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                if (progressBar != null) progressBar.setVisibility(View.GONE);
                Toast.makeText(TeacherDashboardActivity.this, "Error fetching classes", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showError(String message) {
        if (classroomContainer != null) {
            TextView tv = new TextView(TeacherDashboardActivity.this);
            tv.setText(message);
            tv.setPadding(20, 20, 20, 20);
            classroomContainer.addView(tv);
        }
        if (progressBar != null) progressBar.setVisibility(View.GONE);
    }

    private void loadLiveSchedule(String uid) {
        String[] days = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
        Calendar calendar = Calendar.getInstance();
        String todayStr = days[calendar.get(Calendar.DAY_OF_WEEK) - 1];

        if (tvDay != null) tvDay.setText(todayStr + "'s Schedule");

        dbRef.child("TeacherTimetable").child(uid).child(todayStr)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.exists()) {
                            StringBuilder builder = new StringBuilder();
                            for (DataSnapshot slot : snapshot.getChildren()) {
                                builder.append("⏰ ").append(slot.getKey())
                                        .append("\n").append(slot.getValue(String.class))
                                        .append("\n\n");
                            }
                            if (tvTimetable != null) tvTimetable.setText(builder.toString().trim());
                        } else {
                            if (tvTimetable != null) tvTimetable.setText("No personal tasks/classes scheduled for today.");
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {}
                });
    }

    private void createClassButton(String branch, String sem, String div, String sub) {
        if (classroomContainer == null) return;

        Button btn = new Button(this);

        if (sub.equals("Common Class")) {
            btn.setText("📢 Join Common Room (" + branch + " Sem " + sem + ")");
            btn.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#E91E63")));
        } else {
            String label = "Course: " + sub + "\n" + branch + " - Sem " + sem + " (" + div + ")";
            btn.setText(label);
            btn.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#3F51B5")));
        }

        btn.setTextColor(Color.WHITE);
        btn.setPadding(30, 20, 30, 20);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 10, 0, 20);
        btn.setLayoutParams(params);

        btn.setOnClickListener(v -> {
            Intent intent = new Intent(this, ChatActivity.class);
            String safeSubName = sub.replace(" ", "_");
            String roomKey = (branch + "_" + sem + "_" + div + "_" + safeSubName).replace(" ", "_");

            intent.putExtra("ROOM_ID", roomKey);
            intent.putExtra("TITLE", sub + " Chat");
            startActivity(intent);
        });

        classroomContainer.addView(btn);
    }
}