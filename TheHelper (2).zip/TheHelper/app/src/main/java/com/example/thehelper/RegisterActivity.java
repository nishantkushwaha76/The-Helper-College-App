package com.example.thehelper;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.HashMap;

public class RegisterActivity extends AppCompatActivity {

    private EditText etName, etID, etPass, etPhone, etRoll, etPersonalEmail;
    private Spinner spBranch, spSem, spDiv;
    private Button btnReg;
    private RadioButton rbS;
    private RadioGroup roleGroup;
    private LinearLayout studentSpecificLayout;
    private TextView loginRedirect;

    private FirebaseAuth mAuth;
    private DatabaseReference accessRef, userRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mAuth = FirebaseAuth.getInstance();
        accessRef = FirebaseDatabase.getInstance().getReference();
        userRef = FirebaseDatabase.getInstance().getReference("Users");

        // Initialize UI Fields
        etName = findViewById(R.id.etFullName);
        etID = findViewById(R.id.etIdNumber);
        etPass = findViewById(R.id.etPassword);
        etPhone = findViewById(R.id.etPhone);
        etRoll = findViewById(R.id.etRollNumber);
        etPersonalEmail = findViewById(R.id.etPersonalEmail);

        // Spinners
        spBranch = findViewById(R.id.spRegBranch);
        spSem = findViewById(R.id.spRegSem);
        spDiv = findViewById(R.id.spRegDiv);

        studentSpecificLayout = findViewById(R.id.studentSpecificLayout);
        btnReg = findViewById(R.id.btnRegister);
        rbS = findViewById(R.id.rbStudent);
        roleGroup = findViewById(R.id.roleRadioGroup);
        loginRedirect = findViewById(R.id.loginRedirect);

        // 1. SETUP SPINNERS
        setupSpinners();

        // 2. TOGGLE VISIBILITY (Hide Student fields for Teachers)
        roleGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rbTeacher) {
                studentSpecificLayout.setVisibility(View.GONE);
            } else {
                studentSpecificLayout.setVisibility(View.VISIBLE);
            }
        });

        // 3. REGISTER LOGIC
        btnReg.setOnClickListener(v -> registerUser());

        // 4. LOGIN REDIRECT
        loginRedirect.setOnClickListener(v -> {
            startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
            finish();
        });
    }

    private void setupSpinners() {
        String[] branches = {"CSE", "IT", "ECE", "MECH", "CIVIL", "AIDS", "ENTC"};
        String[] sems = {"1", "2", "3", "4", "5", "6", "7", "8"};
        String[] divs = {"A", "B", "C"};

        spBranch.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, branches));
        spSem.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, sems));
        spDiv.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, divs));
    }

    private void registerUser() {
        String id = etID.getText().toString().trim();
        String name = etName.getText().toString().trim();
        String password = etPass.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String pEmail = etPersonalEmail.getText().toString().trim();

        boolean isStudent = rbS.isChecked();
        String role = isStudent ? "Student" : "Teacher";
        String accessPath = isStudent ? "Students" : "Teachers";

        // Get values from Spinners (User Input)
        String branch = isStudent ? spBranch.getSelectedItem().toString() : "N/A";
        String sem = isStudent ? spSem.getSelectedItem().toString() : "N/A";
        String div = isStudent ? spDiv.getSelectedItem().toString() : "N/A";
        String roll = isStudent ? etRoll.getText().toString().trim() : "N/A";

        // Basic Validation
        if(id.isEmpty() || name.isEmpty() || password.length() < 6) {
            Toast.makeText(this, "Fill Name, ID and Password (min 6 chars)", Toast.LENGTH_SHORT).show();
            return;
        }

        // CRITICAL CHECK: Check if Admin authorized this ID
        accessRef.child(accessPath).child(id).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    // ID is allowed! Create account with USER provided details (Spinners)
                    createFirebaseAccount(id, password, name, role, branch, sem, div, phone, roll, pEmail);
                } else {
                    Toast.makeText(RegisterActivity.this, "ID " + id + " not authorized by Admin.", Toast.LENGTH_LONG).show();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(RegisterActivity.this, "DB Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void createFirebaseAccount(String id, String pass, String name, String role,
                                       String branch, String sem, String div,
                                       String phone, String roll, String pEmail) {

        // Construct Authentication Email
        String authEmail = id + (role.equals("Student") ? "@helper.com" : "@staff.com");

        mAuth.createUserWithEmailAndPassword(authEmail, pass)
                .addOnSuccessListener(authResult -> {
                    String uid = mAuth.getUid();
                    HashMap<String, Object> map = new HashMap<>();

                    // Save Profile Data
                    map.put("uid", uid);
                    map.put("fullName", name);
                    map.put("role", role);
                    map.put("prn", id);
                    map.put("branch", branch);
                    map.put("semester", sem);
                    map.put("division", div);
                    map.put("roll", roll);
                    map.put("phone", phone);
                    map.put("personalEmail", pEmail);
                    map.put("isProfileComplete", true);

                    userRef.child(uid).setValue(map).addOnSuccessListener(a -> {
                        Toast.makeText(this, "Registration Successful!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(this, LoginActivity.class));
                        finish();
                    });
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Registration Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }
}