package com.example.thehelper;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class TeacherProfileActivity extends AppCompatActivity {

    private TextView tvName, tvEmail, tvID, tvBranch, tvClass, tvSubject;
    private Button btnLogout;

    private FirebaseAuth mAuth;
    private DatabaseReference dbRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_profile);

        // Bind Views
        tvName = findViewById(R.id.tvProfileName);
        tvEmail = findViewById(R.id.tvProfileEmail);
        tvID = findViewById(R.id.tvProfileID);
        tvBranch = findViewById(R.id.tvProfileBranch);
        tvClass = findViewById(R.id.tvProfileClass);
        tvSubject = findViewById(R.id.tvProfileSubject);
        btnLogout = findViewById(R.id.btnLogout);

        mAuth = FirebaseAuth.getInstance();
        dbRef = FirebaseDatabase.getInstance().getReference();

        loadTeacherData();

        btnLogout.setOnClickListener(v -> {
            mAuth.signOut();
            Intent intent = new Intent(TeacherProfileActivity.this, LoginActivity.class);
            // Clear back stack so they can't press back to return
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    private void loadTeacherData() {
        if (mAuth.getCurrentUser() == null) return;
        String uid = mAuth.getCurrentUser().getUid();

        // 1. First, fetch the Teacher ID (PRN) from the 'Users' table
        dbRef.child("Users").child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String name = snapshot.child("name").getValue(String.class);
                    String email = snapshot.child("email").getValue(String.class);
                    String tid = snapshot.child("prn").getValue(String.class); // This is the Teacher ID

                    tvName.setText(name);
                    tvEmail.setText(email);
                    tvID.setText("Teacher ID: " + tid);

                    // 2. Now fetch the Assignment details from 'Teachers' table
                    if (tid != null) {
                        fetchAssignmentDetails(tid);
                    }
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void fetchAssignmentDetails(String tid) {
        dbRef.child("Teachers").child(tid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String branch = snapshot.child("branch").getValue(String.class);
                    String sem = snapshot.child("semester").getValue(String.class);
                    String div = snapshot.child("division").getValue(String.class);
                    String subject = snapshot.child("subject").getValue(String.class);

                    tvBranch.setText(branch != null ? branch : "Not Assigned");

                    if (sem != null && div != null) {
                        tvClass.setText("Sem " + sem + " - Div " + div);
                    } else {
                        tvClass.setText("Not Assigned");
                    }

                    tvSubject.setText(subject != null ? subject : "Not Assigned");
                } else {
                    Toast.makeText(TeacherProfileActivity.this, "Teacher details not found in database.", Toast.LENGTH_SHORT).show();
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }
}