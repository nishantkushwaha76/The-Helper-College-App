package com.example.thehelper;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class ChatActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private EditText etMessage;
    private Button btnSend;
    private ImageButton btnAttachImage;
    private TextView tvTitle;

    private ChatAdapter adapter;
    private ArrayList<ChatModel> chatList;
    private ArrayList<String> messageIds;

    private DatabaseReference chatRef, userRef;
    private String currentUid, myRole, myName, chatRoomId;

    private ActivityResultLauncher<String> imagePickerLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        // Bind Views
        recyclerView = findViewById(R.id.chatRecyclerView);
        etMessage = findViewById(R.id.etMessageInput);
        btnSend = findViewById(R.id.btnSend);
        btnAttachImage = findViewById(R.id.btnAttachImage);
        tvTitle = findViewById(R.id.tvChatTitle);

        chatList = new ArrayList<>();
        messageIds = new ArrayList<>();
        adapter = new ChatAdapter(this, chatList);

        // Improved LayoutManager to handle keyboard resizing
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setStackFromEnd(true);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);

        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            currentUid = FirebaseAuth.getInstance().getCurrentUser().getUid();
            userRef = FirebaseDatabase.getInstance().getReference("Users").child(currentUid);
            setupChatRoom();
        } else {
            finish(); // Cannot chat without being logged in
        }

        imagePickerLauncher = registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
            if (uri != null) uploadImage(uri);
        });

        btnSend.setOnClickListener(v -> sendMessage());
        btnAttachImage.setOnClickListener(v -> imagePickerLauncher.launch("image/*"));

        // Ensure adapter listener is set
        adapter.setOnItemLongClickListener(this::deleteMessage);
    }

    private void setupChatRoom() {
        if (getIntent().hasExtra("ROOM_ID")) {
            chatRoomId = getIntent().getStringExtra("ROOM_ID");
            String title = getIntent().getStringExtra("TITLE");
            tvTitle.setText(title != null ? title : "Class Discussion");

            // Initialize chatRef immediately to prevent null sending
            chatRef = FirebaseDatabase.getInstance().getReference("Chats").child(chatRoomId);

            fetchMyProfile();
        } else {
            Toast.makeText(this, "Room error", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void fetchMyProfile() {
        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    myName = snapshot.child("fullName").getValue(String.class);
                    myRole = snapshot.child("role").getValue(String.class);

                    // Profile loaded, now we can safely start listening for messages
                    loadMessages();
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void loadMessages() {
        // Use ValueEventListener for real-time updates
        chatRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                chatList.clear();
                messageIds.clear();
                for (DataSnapshot data : snapshot.getChildren()) {
                    ChatModel model = data.getValue(ChatModel.class);
                    if (model != null) {
                        chatList.add(model);
                        messageIds.add(data.getKey());
                    }
                }
                adapter.notifyDataSetChanged();
                if (!chatList.isEmpty()) {
                    recyclerView.scrollToPosition(chatList.size() - 1);
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void sendMessage() {
        String msg = etMessage.getText().toString().trim();

        // Check for nulls to prevent crash
        if (TextUtils.isEmpty(msg)) return;

        if (chatRef == null || myName == null) {
            Toast.makeText(this, "Loading chat connection...", Toast.LENGTH_SHORT).show();
            return;
        }

        ChatModel chat = new ChatModel(myName, msg, myRole, currentUid, System.currentTimeMillis(), "text", null);
        chatRef.push().setValue(chat)
                .addOnFailureListener(e -> Toast.makeText(ChatActivity.this, "Send failed", Toast.LENGTH_SHORT).show());

        etMessage.setText("");
    }

    private void deleteMessage(int position) {
        if (position < 0 || position >= messageIds.size()) return;

        String msgId = messageIds.get(position);
        ChatModel selectedChat = chatList.get(position);

        boolean isTeacher = "Teacher".equalsIgnoreCase(myRole);
        boolean isMyMessage = currentUid.equals(selectedChat.getSenderUid());

        if (isTeacher || isMyMessage) {
            new AlertDialog.Builder(this)
                    .setTitle("Delete Message")
                    .setMessage("Do you want to delete this message?")
                    .setPositiveButton("Delete", (dialog, which) -> {
                        chatRef.child(msgId).removeValue();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        } else {
            Toast.makeText(this, "You can't delete this.", Toast.LENGTH_SHORT).show();
        }
    }

    private void uploadImage(Uri imageUri) {
        if (chatRef == null || myName == null) return;

        try {
            Bitmap originalBitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);
            int newWidth = 500;
            int newHeight = (int) (newWidth * ((float) originalBitmap.getHeight() / originalBitmap.getWidth()));
            Bitmap scaledBitmap = Bitmap.createScaledBitmap(originalBitmap, newWidth, newHeight, true);

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 50, baos); // Lower quality for faster DB performance
            String imageString = Base64.encodeToString(baos.toByteArray(), Base64.DEFAULT);

            ChatModel chat = new ChatModel(myName, "", myRole, currentUid, System.currentTimeMillis(), "image", imageString);
            chatRef.push().setValue(chat);
        } catch (IOException e) {
            Toast.makeText(this, "Image Error", Toast.LENGTH_SHORT).show();
        }
    }
}