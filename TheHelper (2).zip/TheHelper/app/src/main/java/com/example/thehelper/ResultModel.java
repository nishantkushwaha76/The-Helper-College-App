package com.example.thehelper;

/**
 * Model class for Student Results supporting UT1, UT2, Sem, and SGPA calculations.
 */
public class ResultModel {
    private String subject;
    private int credits;
    private int ut1;
    private int ut2;
    private int sem;
    private int total;
    private String status; // "PASS" or "FAIL"

    // 1. Required Empty Constructor for Firebase DataSnapshot.getValue(ResultModel.class)
    public ResultModel() {
    }

    // 2. Constructor with all fields used by AdminActivity to save data
    public ResultModel(String subject, int credits, int ut1, int ut2, int sem, int total, String status) {
        this.subject = subject;
        this.credits = credits;
        this.ut1 = ut1;
        this.ut2 = ut2;
        this.sem = sem;
        this.total = total;
        this.status = status;
    }

    // 3. Getters and Setters (Firebase requires these to read/write data)
    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }

    public int getCredits() { return credits; }
    public void setCredits(int credits) { this.credits = credits; }

    public int getUt1() { return ut1; }
    public void setUt1(int ut1) { this.ut1 = ut1; }

    public int getUt2() { return ut2; }
    public void setUt2(int ut2) { this.ut2 = ut2; }

    public int getSem() { return sem; }
    public void setSem(int sem) { this.sem = sem; }

    public int getTotal() { return total; }
    public void setTotal(int total) { this.total = total; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    // --- SMART HELPER: Calculate Grade Point for SGPA ---
    // Logic: Standard 10-point grading scale based on Total Marks out of 100
    public int getGradePoint() {
        if (total >= 80) return 10;       // O (Outstanding)
        else if (total >= 75) return 9;   // A+
        else if (total >= 70) return 8;   // A
        else if (total >= 60) return 7;   // B+
        else if (total >= 50) return 6;   // B
        else if (total >= 40) return 5;   // C (Pass)
        else return 0;                    // F (Fail)
    }

    // --- SMART HELPER: UI Color Logic ---
    // Returns true if status is PASS to help set text color to Green in the Adapter
    public boolean isPassed() {
        return status != null && status.equalsIgnoreCase("PASS");
    }
}