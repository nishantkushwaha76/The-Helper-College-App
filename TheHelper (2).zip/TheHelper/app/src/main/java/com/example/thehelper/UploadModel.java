package com.example.thehelper;

/**
 * Model class for PDF Materials and Schedule uploads.
 * This class is designed to work with Firebase Realtime Database.
 */
public class UploadModel {
    private String name;
    private String url;

    // 1. Required empty constructor for Firebase DataSnapshot.getValue(UploadModel.class)
    public UploadModel() {
    }

    // 2. Constructor for creating new upload objects in AdminActivity
    public UploadModel(String name, String url) {
        this.name = name;
        this.url = url;
    }

    // 3. Getters - These must match the field names for Firebase to map them correctly
    public String getName() {
        return name;
    }

    public String getUrl() {
        return url;
    }

    // 4. Setters - Required if you plan to modify objects locally
    public void setName(String name) {
        this.name = name;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}